"""!@package AtikSDK

Atik Python SDK package
"""

r"""Wrapper for AtikCameras.h

Generated with:
/home/chris/.local/bin/ctypesgen -l./AtikCameras.dll AtikCameras.h -o __init__.py

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python v(2, 7)
# Code has been updated to Python3
#region GeneratedImports

import ctypes, os, sys
from ctypes import *

_int_types = (c_int16, c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (c_int64,)
for t in _int_types:
    if sizeof(t) == sizeof(c_size_t):
        c_ptrdiff_t = t
del t
del _int_types


class UserString:
    def __init__(self, seq):
        if isinstance(seq, str):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq)

    def __str__(self):
        return str(self.data)

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data)

    def __long__(self):
        return int(self.data)

    def __float__(self):
        return float(self.data)

    def __complex__(self):
        return complex(self.data)

    def __hash__(self):
        return hash(self.data)

    def __cmp__(self, string):
        if isinstance(string, UserString):
            return self.data == string.data
        else:
            return self.data == string

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, str):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other))

    def __radd__(self, other):
        if isinstance(other, str):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other) + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxsize):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxsize):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxsize):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxsize):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxsize):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxsize):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxsize):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, str):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub) + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, str):
            self.data += other
        else:
            self.data += str(other)
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, Union):

    _fields_ = [("raw", POINTER(c_char)), ("data", c_char_p)]

    def __init__(self, obj=""):
        if isinstance(obj, (bytes, str, UserString)):
            self.data = str(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(POINTER(c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj)

        # Convert from c_char_p
        elif isinstance(obj, c_char_p):
            return obj

        # Convert from POINTER(c_char)
        elif isinstance(obj, POINTER(c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(cast(obj, POINTER(c_char)))

        # Convert from c_char array
        elif isinstance(obj, c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if isinstance(value, str) else value

# End preamble

_libs = {}
_libdirs = []

# Begin loader

# ----------------------------------------------------------------------------
# Copyright (c) 2008 David James
# Copyright (c) 2006-2008 Alex Holkner
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of pyglet nor the names of its
#    contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ----------------------------------------------------------------------------

import os.path, re, sys, glob
import platform
import ctypes
import ctypes.util


def _environ_path(name):
    if name in os.environ:
        return os.environ[name].split(":")
    else:
        return []


class LibraryLoader(object):
    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup(object):
        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)

        for path in paths:
            try:
                return self.Lookup(path)
            except:
                pass

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # then we search the directory where the generated python interface is stored
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.dirname(__file__), fmt % libname))

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, libname):
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [format % libname for format in self.name_formats]

        for dir in self.getdirs(libname):
            for name in names:
                yield os.path.join(dir, name)

    def getdirs(self, libname):
        """Implements the dylib search as specified in Apple documentation:

        http://developer.apple.com/documentation/DeveloperTools/Conceptual/
            DynamicLibraries/Articles/DynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [os.path.expanduser("~/lib"), "/usr/local/lib", "/usr/lib"]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))

        if hasattr(sys, "frozen") and sys.frozen == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    class _Directories(dict):
        def __init__(self):
            self.order = 0

        def add(self, directory):
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            o = self.setdefault(directory, self.order)
            if o == self.order:
                self.order += 1

        def extend(self, directories):
            for d in directories:
                self.add(d)

        def ordered(self):
            return (i[0] for i in sorted(self.items(), key=lambda D: D[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive funtion to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as f:
                for D in f:
                    D = D.strip()
                    if not D:
                        continue

                    m = self._include.match(D)
                    if not m:
                        dirs.add(D)
                    else:
                        for D2 in glob.glob(m.group("pattern")):
                            self._get_ld_so_conf_dirs(D2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # /sbin/ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HPUX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("/etc/ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "/usr/lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "/usr/lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https://wiki.ubuntu.com/MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/i386-linux-gnu", "/usr/lib/i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/x86_64-linux-gnu", "/usr/lib/x86_64-linux-gnu"]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("/lib/*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        ext_re = re.compile(r"\.s[ol]$")
        for dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for F in other_dirs:
        if not os.path.isabs(F):
            F = os.path.abspath(F)
        load_library.other_dirs.append(F)


del loaderclass

# End loader

add_library_search_dirs([])

# Begin libraries
_libs[""] = load_library("atikcameras")

# 1 libraries
# End libraries

# No modules

BOOL = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 11

HINSTANCE = POINTER(None)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 13

enum_ARTEMISERROR = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_OK = 0# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_INVALID_PARAMETER = (ARTEMIS_OK + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_NOT_CONNECTED = (ARTEMIS_INVALID_PARAMETER + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_NOT_IMPLEMENTED = (ARTEMIS_NOT_CONNECTED + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_NO_RESPONSE = (ARTEMIS_NOT_IMPLEMENTED + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_INVALID_FUNCTION = (ARTEMIS_NO_RESPONSE + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_NOT_INITIALIZED = (ARTEMIS_INVALID_FUNCTION + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

ARTEMIS_OPERATION_FAILED = (ARTEMIS_NOT_INITIALIZED + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 23

enum_ARTEMISCOLOURTYPE = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 45

ARTEMIS_COLOUR_UNKNOWN = 0# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 45

ARTEMIS_COLOUR_NONE = (ARTEMIS_COLOUR_UNKNOWN + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 45

ARTEMIS_COLOUR_RGGB = (ARTEMIS_COLOUR_NONE + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 45

enum_ARTEMISPRECHARGEMODE = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 56

PRECHARGE_NONE = 0# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 56

PRECHARGE_ICPS = (PRECHARGE_NONE + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 56

PRECHARGE_FULL = (PRECHARGE_ICPS + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 56

enum_ARTEMISCAMERASTATE = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_ERROR = (-1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_IDLE = 0# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_WAITING = (CAMERA_IDLE + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_EXPOSING = (CAMERA_WAITING + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_READING = (CAMERA_EXPOSING + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_DOWNLOADING = (CAMERA_READING + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

CAMERA_FLUSHING = (CAMERA_DOWNLOADING + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 67

enum_ARTEMISCONNECTIONSTATE = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

CAMERA_CONNECTING = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

CAMERA_CONNECTED = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

CAMERA_CONNECT_FAILED = 3# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

CAMERA_SUSPENDED = 4# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

CAMERA_CONNECT_UNKNOWN = 5# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 79

enum_ARTEMISPROCESSING = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 90

ARTEMIS_PROCESS_LINEARISE = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 90

ARTEMIS_PROCESS_VBE = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 90

enum_ARTEMISPROPERTIESCCDFLAGS = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 100

ARTEMIS_PROPERTIES_CCDFLAGS_INTERLACED = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 100

ARTEMIS_PROPERTIES_CCDFLAGS_DUMMY = 2147483647# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 100

enum_ARTEMISPROPERTIESCAMERAFLAGS = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_FIFO = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_EXT_TRIGGER = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_PREVIEW = 4# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_SUBSAMPLE = 8# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_SHUTTER = 16# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_GUIDE_PORT = 32# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_GPIO = 64# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_WINDOW_HEATER = 128# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_EIGHT_BIT_MODE = 256# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_OVERLAP_MODE = 512# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_FILTERWHEEL = 1024# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

ARTEMIS_PROPERTIES_CAMERAFLAGS_DUMMY = 2147483647# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 110

enum_ARTEMISCOOLINGINFO = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_HASCOOLING = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_CONTROLLABLE = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_ONOFFCOOLINGCONTROL = 4# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_POWERLEVELCONTROL = 8# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_SETPOINTCONTROL = 16# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_WARMINGUP = 32# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_COOLINGON = 64# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

ARTEMIS_COOLING_INFO_SETPOINTCONTROLON = 128# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 140

enum_ARTEMISEFWTYPE = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 163

ARTEMIS_EFW1 = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 163

ARTEMIS_EFW2 = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 163

enum_CameraSpecificOptionsIDs = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOPresetMode = 1# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOPresetLow = 2# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOPresetMed = 3# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOPresetHigh = 4# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOCustomGain = 5# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_GOCustomOffset = 6# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_EvenIllumination = 12# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_PadData = 13# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_ExposureSpeed = 14# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_16BitMode        = 18

ID_BitSendMode = 15# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_ReadoutModeTE = 20

ID_FX3Version = 200# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

ID_FPGAVersion = 201# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 171

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 189
class struct_ARTEMISPROPERTIES(Structure):
    pass

struct_ARTEMISPROPERTIES.__slots__ = [
    'Protocol',
    'nPixelsX',
    'nPixelsY',
    'PixelMicronsX',
    'PixelMicronsY',
    'ccdflags',
    'cameraflags',
    'Description',
    'Manufacturer',
]
struct_ARTEMISPROPERTIES._fields_ = [
    ('Protocol', c_int),
    ('nPixelsX', c_int),
    ('nPixelsY', c_int),
    ('PixelMicronsX', c_float),
    ('PixelMicronsY', c_float),
    ('ccdflags', c_int),
    ('cameraflags', c_int),
    ('Description', c_char * int(40)),
    ('Manufacturer', c_char * int(40)),
]

ArtemisHandle = POINTER(None)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 215

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 219
for _lib in _libs.values():
    try:
        hArtemisDLL = (HINSTANCE).in_dll(_lib, "hArtemisDLL")
        break
    except:
        pass

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 235
for _lib in _libs.values():
    if not _lib.has("ArtemisAPIVersion", "cdecl"):
        continue
    ArtemisAPIVersion = _lib.get("ArtemisAPIVersion", "cdecl")
    ArtemisAPIVersion.argtypes = []
    ArtemisAPIVersion.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 239
for _lib in _libs.values():
    if not _lib.has("ArtemisDLLVersion", "cdecl"):
        continue
    ArtemisDLLVersion = _lib.get("ArtemisDLLVersion", "cdecl")
    ArtemisDLLVersion.argtypes = []
    ArtemisDLLVersion.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 243
for _lib in _libs.values():
    if not _lib.has("ArtemisIsLocalConnection", "cdecl"):
        continue
    ArtemisIsLocalConnection = _lib.get("ArtemisIsLocalConnection", "cdecl")
    ArtemisIsLocalConnection.argtypes = []
    ArtemisIsLocalConnection.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 248
for _lib in _libs.values():
    if not _lib.has("ArtemisAllowDebugToConsole", "cdecl"):
        continue
    ArtemisAllowDebugToConsole = _lib.get("ArtemisAllowDebugToConsole", "cdecl")
    ArtemisAllowDebugToConsole.argtypes = [c_bool]
    ArtemisAllowDebugToConsole.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 254
for _lib in _libs.values():
    if not _lib.has("ArtemisSetDebugCallback", "cdecl"):
        continue
    ArtemisSetDebugCallback = _lib.get("ArtemisSetDebugCallback", "cdecl")
    ArtemisSetDebugCallback.argtypes = [CFUNCTYPE(UNCHECKED(None), String)]
    ArtemisSetDebugCallback.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 262
for _lib in _libs.values():
    if not _lib.has("ArtemisSetDebugCallbackContext", "cdecl"):
        continue
    ArtemisSetDebugCallbackContext = _lib.get("ArtemisSetDebugCallbackContext", "cdecl")
    ArtemisSetDebugCallbackContext.argtypes = [POINTER(None), CFUNCTYPE(UNCHECKED(None), POINTER(None), String)]
    ArtemisSetDebugCallbackContext.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 266
for _lib in _libs.values():
    if not _lib.has("ArtemisSetFirmwareDir", "cdecl"):
        continue
    ArtemisSetFirmwareDir = _lib.get("ArtemisSetFirmwareDir", "cdecl")
    ArtemisSetFirmwareDir.argtypes = [String]
    ArtemisSetFirmwareDir.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 271
for _lib in _libs.values():
    if not _lib.has("ArtemisSetAtikAir", "cdecl"):
        continue
    ArtemisSetAtikAir = _lib.get("ArtemisSetAtikAir", "cdecl")
    ArtemisSetAtikAir.argtypes = [String, c_int]
    ArtemisSetAtikAir.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 275
for _lib in _libs.values():
    if not _lib.has("ArtemisShutdown", "cdecl"):
        continue
    ArtemisShutdown = _lib.get("ArtemisShutdown", "cdecl")
    ArtemisShutdown.argtypes = []
    ArtemisShutdown.restype = None
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 282
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceCount", "cdecl"):
        continue
    ArtemisDeviceCount = _lib.get("ArtemisDeviceCount", "cdecl")
    ArtemisDeviceCount.argtypes = []
    ArtemisDeviceCount.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 288
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceIsPresent", "cdecl"):
        continue
    ArtemisDeviceIsPresent = _lib.get("ArtemisDeviceIsPresent", "cdecl")
    ArtemisDeviceIsPresent.argtypes = [c_int]
    ArtemisDeviceIsPresent.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 293
for _lib in _libs.values():
    if not _lib.has("ArtemisDevicePresent", "cdecl"):
        continue
    ArtemisDevicePresent = _lib.get("ArtemisDevicePresent", "cdecl")
    ArtemisDevicePresent.argtypes = [c_int]
    ArtemisDevicePresent.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 298
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceInUse", "cdecl"):
        continue
    ArtemisDeviceInUse = _lib.get("ArtemisDeviceInUse", "cdecl")
    ArtemisDeviceInUse.argtypes = [c_int]
    ArtemisDeviceInUse.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 304
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceName", "cdecl"):
        continue
    ArtemisDeviceName = _lib.get("ArtemisDeviceName", "cdecl")
    ArtemisDeviceName.argtypes = [c_int, c_char_p]
    ArtemisDeviceName.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 310
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceSerial", "cdecl"):
        continue
    ArtemisDeviceSerial = _lib.get("ArtemisDeviceSerial", "cdecl")
    ArtemisDeviceSerial.argtypes = [c_int, POINTER(c_char)]
    ArtemisDeviceSerial.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 315
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceIsCamera", "cdecl"):
        continue
    ArtemisDeviceIsCamera = _lib.get("ArtemisDeviceIsCamera", "cdecl")
    ArtemisDeviceIsCamera.argtypes = [c_int]
    ArtemisDeviceIsCamera.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 320
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceHasFilterWheel", "cdecl"):
        continue
    ArtemisDeviceHasFilterWheel = _lib.get("ArtemisDeviceHasFilterWheel", "cdecl")
    ArtemisDeviceHasFilterWheel.argtypes = [c_int]
    ArtemisDeviceHasFilterWheel.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 325
for _lib in _libs.values():
    if not _lib.has("ArtemisDeviceHasGuidePort", "cdecl"):
        continue
    ArtemisDeviceHasGuidePort = _lib.get("ArtemisDeviceHasGuidePort", "cdecl")
    ArtemisDeviceHasGuidePort.argtypes = [c_int]
    ArtemisDeviceHasGuidePort.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 332
for _lib in _libs.values():
    if not _lib.has("ArtemisConnect", "cdecl"):
        continue
    ArtemisConnect = _lib.get("ArtemisConnect", "cdecl")
    ArtemisConnect.argtypes = [c_int]
    ArtemisConnect.restype = ArtemisHandle
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 337
for _lib in _libs.values():
    if not _lib.has("ArtemisIsConnected", "cdecl"):
        continue
    ArtemisIsConnected = _lib.get("ArtemisIsConnected", "cdecl")
    ArtemisIsConnected.argtypes = [ArtemisHandle]
    ArtemisIsConnected.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 343
for _lib in _libs.values():
    if not _lib.has("ArtemisDisconnect", "cdecl"):
        continue
    ArtemisDisconnect = _lib.get("ArtemisDisconnect", "cdecl")
    ArtemisDisconnect.argtypes = [ArtemisHandle]
    ArtemisDisconnect.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 348
for _lib in _libs.values():
    if not _lib.has("ArtemisRefreshDevicesCount", "cdecl"):
        continue
    ArtemisRefreshDevicesCount = _lib.get("ArtemisRefreshDevicesCount", "cdecl")
    ArtemisRefreshDevicesCount.argtypes = []
    ArtemisRefreshDevicesCount.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 358
for _lib in _libs.values():
    if not _lib.has("ArtemisCameraSerial", "cdecl"):
        continue
    ArtemisCameraSerial = _lib.get("ArtemisCameraSerial", "cdecl")
    ArtemisCameraSerial.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int)]
    ArtemisCameraSerial.restype = c_int
    break

for _lib in _libs.values():
    if not _lib.has("ArtemisCameraSerialEx", "cdecl"):
        continue
    ArtemisCameraSerialEx = _lib.get("ArtemisCameraSerialEx", "cdecl")
    ArtemisCameraSerialEx.argtypes = [ArtemisHandle, POINTER(c_char_p)]
    ArtemisCameraSerialEx.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 369
for _lib in _libs.values():
    if not _lib.has("ArtemisColourProperties", "cdecl"):
        continue
    ArtemisColourProperties = _lib.get("ArtemisColourProperties", "cdecl")
    ArtemisColourProperties.argtypes = [ArtemisHandle, POINTER(enum_ARTEMISCOLOURTYPE), POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisColourProperties.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 376
for _lib in _libs.values():
    if not _lib.has("ArtemisProperties", "cdecl"):
        continue
    ArtemisProperties = _lib.get("ArtemisProperties", "cdecl")
    ArtemisProperties.argtypes = [ArtemisHandle, POINTER(struct_ARTEMISPROPERTIES)]
    ArtemisProperties.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 383
for _lib in _libs.values():
    if not _lib.has("ArtemisCameraConnectionState", "cdecl"):
        continue
    ArtemisCameraConnectionState = _lib.get("ArtemisCameraConnectionState", "cdecl")
    ArtemisCameraConnectionState.argtypes = [ArtemisHandle, POINTER(enum_ARTEMISCONNECTIONSTATE)]
    ArtemisCameraConnectionState.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 394
for _lib in _libs.values():
    if not _lib.has("ArtemisBin", "cdecl"):
        continue
    ArtemisBin = _lib.get("ArtemisBin", "cdecl")
    ArtemisBin.argtypes = [ArtemisHandle, c_int, c_int]
    ArtemisBin.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 402
for _lib in _libs.values():
    if not _lib.has("ArtemisGetBin", "cdecl"):
        continue
    ArtemisGetBin = _lib.get("ArtemisGetBin", "cdecl")
    ArtemisGetBin.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int)]
    ArtemisGetBin.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 410
for _lib in _libs.values():
    if not _lib.has("ArtemisGetMaxBin", "cdecl"):
        continue
    ArtemisGetMaxBin = _lib.get("ArtemisGetMaxBin", "cdecl")
    ArtemisGetMaxBin.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int)]
    ArtemisGetMaxBin.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 420
for _lib in _libs.values():
    if not _lib.has("ArtemisGetSubframe", "cdecl"):
        continue
    ArtemisGetSubframe = _lib.get("ArtemisGetSubframe", "cdecl")
    ArtemisGetSubframe.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisGetSubframe.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 431
for _lib in _libs.values():
    if not _lib.has("ArtemisSubframe", "cdecl"):
        continue
    ArtemisSubframe = _lib.get("ArtemisSubframe", "cdecl")
    ArtemisSubframe.argtypes = [ArtemisHandle, c_int, c_int, c_int, c_int]
    ArtemisSubframe.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 439
for _lib in _libs.values():
    if not _lib.has("ArtemisSubframePos", "cdecl"):
        continue
    ArtemisSubframePos = _lib.get("ArtemisSubframePos", "cdecl")
    ArtemisSubframePos.argtypes = [ArtemisHandle, c_int, c_int]
    ArtemisSubframePos.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 447
for _lib in _libs.values():
    if not _lib.has("ArtemisSubframeSize", "cdecl"):
        continue
    ArtemisSubframeSize = _lib.get("ArtemisSubframeSize", "cdecl")
    ArtemisSubframeSize.argtypes = [ArtemisHandle, c_int, c_int]
    ArtemisSubframeSize.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 454
for _lib in _libs.values():
    if not _lib.has("ArtemisSetSubSample", "cdecl"):
        continue
    ArtemisSetSubSample = _lib.get("ArtemisSetSubSample", "cdecl")
    ArtemisSetSubSample.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetSubSample.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 460
for _lib in _libs.values():
    if not _lib.has("ArtemisContinuousExposingModeSupported", "cdecl"):
        continue
    ArtemisContinuousExposingModeSupported = _lib.get("ArtemisContinuousExposingModeSupported", "cdecl")
    ArtemisContinuousExposingModeSupported.argtypes = [ArtemisHandle]
    ArtemisContinuousExposingModeSupported.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 466
for _lib in _libs.values():
    if not _lib.has("ArtemisGetContinuousExposingMode", "cdecl"):
        continue
    ArtemisGetContinuousExposingMode = _lib.get("ArtemisGetContinuousExposingMode", "cdecl")
    ArtemisGetContinuousExposingMode.argtypes = [ArtemisHandle]
    ArtemisGetContinuousExposingMode.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 474
for _lib in _libs.values():
    if not _lib.has("ArtemisSetContinuousExposingMode", "cdecl"):
        continue
    ArtemisSetContinuousExposingMode = _lib.get("ArtemisSetContinuousExposingMode", "cdecl")
    ArtemisSetContinuousExposingMode.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetContinuousExposingMode.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 479
for _lib in _libs.values():
    if not _lib.has("ArtemisGetDarkMode", "cdecl"):
        continue
    ArtemisGetDarkMode = _lib.get("ArtemisGetDarkMode", "cdecl")
    ArtemisGetDarkMode.argtypes = [ArtemisHandle]
    ArtemisGetDarkMode.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 486
for _lib in _libs.values():
    if not _lib.has("ArtemisSetDarkMode", "cdecl"):
        continue
    ArtemisSetDarkMode = _lib.get("ArtemisSetDarkMode", "cdecl")
    ArtemisSetDarkMode.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetDarkMode.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 495
for _lib in _libs.values():
    if not _lib.has("ArtemisSetPreview", "cdecl"):
        continue
    ArtemisSetPreview = _lib.get("ArtemisSetPreview", "cdecl")
    ArtemisSetPreview.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetPreview.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 502
for _lib in _libs.values():
    if not _lib.has("ArtemisAutoAdjustBlackLevel", "cdecl"):
        continue
    ArtemisAutoAdjustBlackLevel = _lib.get("ArtemisAutoAdjustBlackLevel", "cdecl")
    ArtemisAutoAdjustBlackLevel.argtypes = [ArtemisHandle, c_bool]
    ArtemisAutoAdjustBlackLevel.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 510
for _lib in _libs.values():
    if not _lib.has("ArtemisPrechargeMode", "cdecl"):
        continue
    ArtemisPrechargeMode = _lib.get("ArtemisPrechargeMode", "cdecl")
    ArtemisPrechargeMode.argtypes = [ArtemisHandle, c_int]
    ArtemisPrechargeMode.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 518
for _lib in _libs.values():
    if not _lib.has("ArtemisEightBitMode", "cdecl"):
        continue
    ArtemisEightBitMode = _lib.get("ArtemisEightBitMode", "cdecl")
    ArtemisEightBitMode.argtypes = [ArtemisHandle, c_bool]
    ArtemisEightBitMode.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 525
for _lib in _libs.values():
    if not _lib.has("ArtemisGetEightBitMode", "cdecl"):
        continue
    ArtemisGetEightBitMode = _lib.get("ArtemisGetEightBitMode", "cdecl")
    ArtemisGetEightBitMode.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisGetEightBitMode.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 531
for _lib in _libs.values():
    if not _lib.has("ArtemisStartOverlappedExposure", "cdecl"):
        continue
    ArtemisStartOverlappedExposure = _lib.get("ArtemisStartOverlappedExposure", "cdecl")
    ArtemisStartOverlappedExposure.argtypes = [ArtemisHandle]
    ArtemisStartOverlappedExposure.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 536
for _lib in _libs.values():
    if not _lib.has("ArtemisOverlappedExposureValid", "cdecl"):
        continue
    ArtemisOverlappedExposureValid = _lib.get("ArtemisOverlappedExposureValid", "cdecl")
    ArtemisOverlappedExposureValid.argtypes = [ArtemisHandle]
    ArtemisOverlappedExposureValid.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 543
for _lib in _libs.values():
    if not _lib.has("ArtemisSetOverlappedExposureTime", "cdecl"):
        continue
    ArtemisSetOverlappedExposureTime = _lib.get("ArtemisSetOverlappedExposureTime", "cdecl")
    ArtemisSetOverlappedExposureTime.argtypes = [ArtemisHandle, c_float]
    ArtemisSetOverlappedExposureTime.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 550
for _lib in _libs.values():
    if not _lib.has("ArtemisTriggeredExposure", "cdecl"):
        continue
    ArtemisTriggeredExposure = _lib.get("ArtemisTriggeredExposure", "cdecl")
    ArtemisTriggeredExposure.argtypes = [ArtemisHandle, c_bool]
    ArtemisTriggeredExposure.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 556
for _lib in _libs.values():
    if not _lib.has("ArtemisGetProcessing", "cdecl"):
        continue
    ArtemisGetProcessing = _lib.get("ArtemisGetProcessing", "cdecl")
    ArtemisGetProcessing.argtypes = [ArtemisHandle]
    ArtemisGetProcessing.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 563
for _lib in _libs.values():
    if not _lib.has("ArtemisSetProcessing", "cdecl"):
        continue
    ArtemisSetProcessing = _lib.get("ArtemisSetProcessing", "cdecl")
    ArtemisSetProcessing.argtypes = [ArtemisHandle, c_int]
    ArtemisSetProcessing.restype = c_int
    break

for _lib in _libs.values():
    if not _lib.has("ArtemisAutoExposureLength", "cdecl"):
        continue
    ArtemisAutoExposureLength = _lib.get("ArtemisAutoExposureLength", "cdecl")
    ArtemisAutoExposureLength.argtypes = [ArtemisHandle, c_int, c_uint16, POINTER(c_float), c_float, c_float, c_float]
    ArtemisAutoExposureLength.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 573
for _lib in _libs.values():
    if not _lib.has("ArtemisStartExposure", "cdecl"):
        continue
    ArtemisStartExposure = _lib.get("ArtemisStartExposure", "cdecl")
    ArtemisStartExposure.argtypes = [ArtemisHandle, c_float]
    ArtemisStartExposure.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 580
for _lib in _libs.values():
    if not _lib.has("ArtemisStartExposureMS", "cdecl"):
        continue
    ArtemisStartExposureMS = _lib.get("ArtemisStartExposureMS", "cdecl")
    ArtemisStartExposureMS.argtypes = [ArtemisHandle, c_int]
    ArtemisStartExposureMS.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 587
for _lib in _libs.values():
    if not _lib.has("ArtemisAbortExposure", "cdecl"):
        continue
    ArtemisAbortExposure = _lib.get("ArtemisAbortExposure", "cdecl")
    ArtemisAbortExposure.argtypes = [ArtemisHandle]
    ArtemisAbortExposure.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 594
for _lib in _libs.values():
    if not _lib.has("ArtemisStopExposure", "cdecl"):
        continue
    ArtemisStopExposure = _lib.get("ArtemisStopExposure", "cdecl")
    ArtemisStopExposure.argtypes = [ArtemisHandle]
    ArtemisStopExposure.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 602
for _lib in _libs.values():
    if not _lib.has("ArtemisImageReady", "cdecl"):
        continue
    ArtemisImageReady = _lib.get("ArtemisImageReady", "cdecl")
    ArtemisImageReady.argtypes = [ArtemisHandle]
    ArtemisImageReady.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 608
for _lib in _libs.values():
    if not _lib.has("ArtemisCameraState", "cdecl"):
        continue
    ArtemisCameraState = _lib.get("ArtemisCameraState", "cdecl")
    ArtemisCameraState.argtypes = [ArtemisHandle]
    ArtemisCameraState.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 615
for _lib in _libs.values():
    if not _lib.has("ArtemisExposureTimeRemaining", "cdecl"):
        continue
    ArtemisExposureTimeRemaining = _lib.get("ArtemisExposureTimeRemaining", "cdecl")
    ArtemisExposureTimeRemaining.argtypes = [ArtemisHandle]
    ArtemisExposureTimeRemaining.restype = c_float
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 621
for _lib in _libs.values():
    if not _lib.has("ArtemisDownloadPercent", "cdecl"):
        continue
    ArtemisDownloadPercent = _lib.get("ArtemisDownloadPercent", "cdecl")
    ArtemisDownloadPercent.argtypes = [ArtemisHandle]
    ArtemisDownloadPercent.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 633
for _lib in _libs.values():
    if not _lib.has("ArtemisGetImageData", "cdecl"):
        continue
    ArtemisGetImageData = _lib.get("ArtemisGetImageData", "cdecl")
    ArtemisGetImageData.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisGetImageData.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 640
for _lib in _libs.values():
    if not _lib.has("ArtemisImageBuffer", "cdecl"):
        continue
    ArtemisImageBuffer = _lib.get("ArtemisImageBuffer", "cdecl")
    ArtemisImageBuffer.argtypes = [ArtemisHandle]
    ArtemisImageBuffer.restype = POINTER(c_ubyte)
    ArtemisImageBuffer.errcheck = lambda v,*a : cast(v, c_void_p)
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 645
for _lib in _libs.values():
    if not _lib.has("ArtemisLastExposureDuration", "cdecl"):
        continue
    ArtemisLastExposureDuration = _lib.get("ArtemisLastExposureDuration", "cdecl")
    ArtemisLastExposureDuration.argtypes = [ArtemisHandle]
    ArtemisLastExposureDuration.restype = c_float
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 653
for _lib in _libs.values():
    if not _lib.has("ArtemisLastStartTime", "cdecl"):
        continue
    ArtemisLastStartTime = _lib.get("ArtemisLastStartTime", "cdecl")
    ArtemisLastStartTime.argtypes = [ArtemisHandle]
    if sizeof(c_int) == sizeof(c_void_p):
        ArtemisLastStartTime.restype = ReturnString
    else:
        ArtemisLastStartTime.restype = String
        ArtemisLastStartTime.errcheck = ReturnString
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 659
for _lib in _libs.values():
    if not _lib.has("ArtemisLastStartTimeMilliseconds", "cdecl"):
        continue
    ArtemisLastStartTimeMilliseconds = _lib.get("ArtemisLastStartTimeMilliseconds", "cdecl")
    ArtemisLastStartTimeMilliseconds.argtypes = [ArtemisHandle]
    ArtemisLastStartTimeMilliseconds.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 665
for _lib in _libs.values():
    if not _lib.has("ArtemisClearVReg", "cdecl"):
        continue
    ArtemisClearVReg = _lib.get("ArtemisClearVReg", "cdecl")
    ArtemisClearVReg.argtypes = [ArtemisHandle]
    ArtemisClearVReg.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 670
for _lib in _libs.values():
    if not _lib.has("ArtemisHasFastMode", "cdecl"):
        continue
    ArtemisHasFastMode = _lib.get("ArtemisHasFastMode", "cdecl")
    ArtemisHasFastMode.argtypes = [ArtemisHandle]
    ArtemisHasFastMode.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 676
for _lib in _libs.values():
    if not _lib.has("ArtemisStartFastExposure", "cdecl"):
        continue
    ArtemisStartFastExposure = _lib.get("ArtemisStartFastExposure", "cdecl")
    ArtemisStartFastExposure.argtypes = [ArtemisHandle, c_int]
    ArtemisStartFastExposure.restype = BOOL
    break

FastCallback = CFUNCTYPE(UNCHECKED(None), ArtemisHandle, c_int, c_int, c_int, c_int, c_int, c_int, POINTER(None))
FastCallbackEx = CFUNCTYPE(UNCHECKED(None), ArtemisHandle, c_int, c_int, c_int, c_int, c_int, c_int, POINTER(None), POINTER(c_ubyte))

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 682
for _lib in _libs.values():
    if not _lib.has("ArtemisSetFastCallback", "cdecl"):
        continue
    ArtemisSetFastCallback = _lib.get("ArtemisSetFastCallback", "cdecl")
    ArtemisSetFastCallback.argtypes = [ArtemisHandle, FastCallback]
    ArtemisSetFastCallback.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 690
for _lib in _libs.values():
    if not _lib.has("ArtemisSetFastCallbackEx", "cdecl"):
        continue
    ArtemisSetFastCallbackEx = _lib.get("ArtemisSetFastCallbackEx", "cdecl")
    ArtemisSetFastCallbackEx.argtypes = [ArtemisHandle, FastCallbackEx]
    ArtemisSetFastCallbackEx.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 699
for _lib in _libs.values():
    if not _lib.has("ArtemisLastFastModeStartTime", "cdecl"):
        continue
    ArtemisLastFastModeStartTime = _lib.get("ArtemisLastFastModeStartTime", "cdecl")
    ArtemisLastFastModeStartTime.argtypes = [ArtemisHandle]
    if sizeof(c_int) == sizeof(c_void_p):
        ArtemisLastFastModeStartTime.restype = ReturnString
    else:
        ArtemisLastFastModeStartTime.restype = String
        ArtemisLastFastModeStartTime.errcheck = ReturnString
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 706
for _lib in _libs.values():
    if not _lib.has("ArtemisLastFastModeStartTimeMilliseconds", "cdecl"):
        continue
    ArtemisLastFastModeStartTimeMilliseconds = _lib.get("ArtemisLastFastModeStartTimeMilliseconds", "cdecl")
    ArtemisLastFastModeStartTimeMilliseconds.argtypes = [ArtemisHandle]
    ArtemisLastFastModeStartTimeMilliseconds.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 716
for _lib in _libs.values():
    if not _lib.has("ArtemisAmplifier", "cdecl"):
        continue
    ArtemisAmplifier = _lib.get("ArtemisAmplifier", "cdecl")
    ArtemisAmplifier.argtypes = [ArtemisHandle, c_bool]
    ArtemisAmplifier.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 721
for _lib in _libs.values():
    if not _lib.has("ArtemisGetAmplifierSwitched", "cdecl"):
        continue
    ArtemisGetAmplifierSwitched = _lib.get("ArtemisGetAmplifierSwitched", "cdecl")
    ArtemisGetAmplifierSwitched.argtypes = [ArtemisHandle]
    ArtemisGetAmplifierSwitched.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 729
for _lib in _libs.values():
    if not _lib.has("ArtemisSetAmplifierSwitched", "cdecl"):
        continue
    ArtemisSetAmplifierSwitched = _lib.get("ArtemisSetAmplifierSwitched", "cdecl")
    ArtemisSetAmplifierSwitched.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetAmplifierSwitched.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 737
for _lib in _libs.values():
    if not _lib.has("ArtemisHasCameraSpecificOption", "cdecl"):
        continue
    ArtemisHasCameraSpecificOption = _lib.get("ArtemisHasCameraSpecificOption", "cdecl")
    ArtemisHasCameraSpecificOption.argtypes = [ArtemisHandle, c_ushort]
    ArtemisHasCameraSpecificOption.restype = c_bool
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 747
for _lib in _libs.values():
    if not _lib.has("ArtemisCameraSpecificOptionGetData", "cdecl"):
        continue
    ArtemisCameraSpecificOptionGetData = _lib.get("ArtemisCameraSpecificOptionGetData", "cdecl")
    ArtemisCameraSpecificOptionGetData.argtypes = [ArtemisHandle, c_ushort, POINTER(c_ubyte), c_int, POINTER(c_int)]
    ArtemisCameraSpecificOptionGetData.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 756
for _lib in _libs.values():
    if not _lib.has("ArtemisCameraSpecificOptionSetData", "cdecl"):
        continue
    ArtemisCameraSpecificOptionSetData = _lib.get("ArtemisCameraSpecificOptionSetData", "cdecl")
    ArtemisCameraSpecificOptionSetData.argtypes = [ArtemisHandle, c_ushort, POINTER(c_ubyte), c_int]
    ArtemisCameraSpecificOptionSetData.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 766
for _lib in _libs.values():
    if not _lib.has("ArtemisSetColumnRepairColumns", "cdecl"):
        continue
    ArtemisSetColumnRepairColumns = _lib.get("ArtemisSetColumnRepairColumns", "cdecl")
    ArtemisSetColumnRepairColumns.argtypes = [ArtemisHandle, c_int, POINTER(c_ushort)]
    ArtemisSetColumnRepairColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 774
for _lib in _libs.values():
    if not _lib.has("ArtemisGetColumnRepairColumns", "cdecl"):
        continue
    ArtemisGetColumnRepairColumns = _lib.get("ArtemisGetColumnRepairColumns", "cdecl")
    ArtemisGetColumnRepairColumns.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_ushort)]
    ArtemisGetColumnRepairColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 780
for _lib in _libs.values():
    if not _lib.has("ArtemisClearColumnRepairColumns", "cdecl"):
        continue
    ArtemisClearColumnRepairColumns = _lib.get("ArtemisClearColumnRepairColumns", "cdecl")
    ArtemisClearColumnRepairColumns.argtypes = [ArtemisHandle]
    ArtemisClearColumnRepairColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 787
for _lib in _libs.values():
    if not _lib.has("ArtemisSetColumnRepairFixColumns", "cdecl"):
        continue
    ArtemisSetColumnRepairFixColumns = _lib.get("ArtemisSetColumnRepairFixColumns", "cdecl")
    ArtemisSetColumnRepairFixColumns.argtypes = [ArtemisHandle, c_bool]
    ArtemisSetColumnRepairFixColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 794
for _lib in _libs.values():
    if not _lib.has("ArtemisGetColumnRepairFixColumns", "cdecl"):
        continue
    ArtemisGetColumnRepairFixColumns = _lib.get("ArtemisGetColumnRepairFixColumns", "cdecl")
    ArtemisGetColumnRepairFixColumns.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisGetColumnRepairFixColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 801
for _lib in _libs.values():
    if not _lib.has("ArtemisGetColumnRepairCanFixColumns", "cdecl"):
        continue
    ArtemisGetColumnRepairCanFixColumns = _lib.get("ArtemisGetColumnRepairCanFixColumns", "cdecl")
    ArtemisGetColumnRepairCanFixColumns.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisGetColumnRepairCanFixColumns.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 811
for _lib in _libs.values():
    if not _lib.has("ArtemisCanInteractWithEEPROM", "cdecl"):
        continue
    ArtemisCanInteractWithEEPROM = _lib.get("ArtemisCanInteractWithEEPROM", "cdecl")
    ArtemisCanInteractWithEEPROM.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisCanInteractWithEEPROM.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 822
for _lib in _libs.values():
    if not _lib.has("ArtemisWriteToEEPROM", "cdecl"):
        continue
    ArtemisWriteToEEPROM = _lib.get("ArtemisWriteToEEPROM", "cdecl")
    ArtemisWriteToEEPROM.argtypes = [ArtemisHandle, String, c_int, c_int, POINTER(c_ubyte)]
    ArtemisWriteToEEPROM.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 833
for _lib in _libs.values():
    if not _lib.has("ArtemisReadFromEEPROM", "cdecl"):
        continue
    ArtemisReadFromEEPROM = _lib.get("ArtemisReadFromEEPROM", "cdecl")
    ArtemisReadFromEEPROM.argtypes = [ArtemisHandle, String, c_int, c_int, POINTER(c_ubyte)]
    ArtemisReadFromEEPROM.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 846
for _lib in _libs.values():
    if not _lib.has("ArtemisFilterWheelInfo", "cdecl"):
        continue
    ArtemisFilterWheelInfo = _lib.get("ArtemisFilterWheelInfo", "cdecl")
    ArtemisFilterWheelInfo.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisFilterWheelInfo.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 853
for _lib in _libs.values():
    if not _lib.has("ArtemisFilterWheelMove", "cdecl"):
        continue
    ArtemisFilterWheelMove = _lib.get("ArtemisFilterWheelMove", "cdecl")
    ArtemisFilterWheelMove.argtypes = [ArtemisHandle, c_int]
    ArtemisFilterWheelMove.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 858
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWIsPresent", "cdecl"):
        continue
    ArtemisEFWIsPresent = _lib.get("ArtemisEFWIsPresent", "cdecl")
    ArtemisEFWIsPresent.argtypes = [c_int]
    ArtemisEFWIsPresent.restype = BOOL
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 867
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWGetDeviceDetails", "cdecl"):
        continue
    ArtemisEFWGetDeviceDetails = _lib.get("ArtemisEFWGetDeviceDetails", "cdecl")
    ArtemisEFWGetDeviceDetails.argtypes = [c_int, POINTER(enum_ARTEMISEFWTYPE), String]
    ArtemisEFWGetDeviceDetails.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 872
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWConnect", "cdecl"):
        continue
    ArtemisEFWConnect = _lib.get("ArtemisEFWConnect", "cdecl")
    ArtemisEFWConnect.argtypes = [c_int]
    ArtemisEFWConnect.restype = ArtemisHandle
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 878
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWIsConnected", "cdecl"):
        continue
    ArtemisEFWIsConnected = _lib.get("ArtemisEFWIsConnected", "cdecl")
    ArtemisEFWIsConnected.argtypes = [ArtemisHandle]
    ArtemisEFWIsConnected.restype = c_bool
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 883
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWDisconnect", "cdecl"):
        continue
    ArtemisEFWDisconnect = _lib.get("ArtemisEFWDisconnect", "cdecl")
    ArtemisEFWDisconnect.argtypes = [ArtemisHandle]
    ArtemisEFWDisconnect.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 891
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWGetDetails", "cdecl"):
        continue
    ArtemisEFWGetDetails = _lib.get("ArtemisEFWGetDetails", "cdecl")
    ArtemisEFWGetDetails.argtypes = [ArtemisHandle, POINTER(enum_ARTEMISEFWTYPE), c_char_p]
    ArtemisEFWGetDetails.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 897
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWNmrPosition", "cdecl"):
        continue
    ArtemisEFWNmrPosition = _lib.get("ArtemisEFWNmrPosition", "cdecl")
    ArtemisEFWNmrPosition.argtypes = [ArtemisHandle, POINTER(c_int)]
    ArtemisEFWNmrPosition.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 903
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWSetPosition", "cdecl"):
        continue
    ArtemisEFWSetPosition = _lib.get("ArtemisEFWSetPosition", "cdecl")
    ArtemisEFWSetPosition.argtypes = [ArtemisHandle, c_int]
    ArtemisEFWSetPosition.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 910
for _lib in _libs.values():
    if not _lib.has("ArtemisEFWGetPosition", "cdecl"):
        continue
    ArtemisEFWGetPosition = _lib.get("ArtemisEFWGetPosition", "cdecl")
    ArtemisEFWGetPosition.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_bool)]
    ArtemisEFWGetPosition.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 918
for _lib in _libs.values():
    if not _lib.has("ArtemisCanUploadFirmware", "cdecl"):
        continue
    ArtemisCanUploadFirmware = _lib.get("ArtemisCanUploadFirmware", "cdecl")
    ArtemisCanUploadFirmware.argtypes = [ArtemisHandle]
    ArtemisCanUploadFirmware.restype = c_bool
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 927
for _lib in _libs.values():
    if not _lib.has("ArtemisUploadFirmware", "cdecl"):
        continue
    ArtemisUploadFirmware = _lib.get("ArtemisUploadFirmware", "cdecl")
    ArtemisUploadFirmware.argtypes = [ArtemisHandle, String, String]
    ArtemisUploadFirmware.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 939
for _lib in _libs.values():
    if not _lib.has("ArtemisGetGain", "cdecl"):
        continue
    ArtemisGetGain = _lib.get("ArtemisGetGain", "cdecl")
    ArtemisGetGain.argtypes = [ArtemisHandle, c_bool, POINTER(c_int), POINTER(c_int)]
    ArtemisGetGain.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 949
for _lib in _libs.values():
    if not _lib.has("ArtemisSetGain", "cdecl"):
        continue
    ArtemisSetGain = _lib.get("ArtemisSetGain", "cdecl")
    ArtemisSetGain.argtypes = [ArtemisHandle, c_bool, c_int, c_int]
    ArtemisSetGain.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 959
for _lib in _libs.values():
    if not _lib.has("ArtemisGetGpioInformation", "cdecl"):
        continue
    ArtemisGetGpioInformation = _lib.get("ArtemisGetGpioInformation", "cdecl")
    ArtemisGetGpioInformation.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int)]
    ArtemisGetGpioInformation.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 966
for _lib in _libs.values():
    if not _lib.has("ArtemisSetGpioDirection", "cdecl"):
        continue
    ArtemisSetGpioDirection = _lib.get("ArtemisSetGpioDirection", "cdecl")
    ArtemisSetGpioDirection.argtypes = [ArtemisHandle, c_int]
    ArtemisSetGpioDirection.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 973
for _lib in _libs.values():
    if not _lib.has("ArtemisSetGpioValues", "cdecl"):
        continue
    ArtemisSetGpioValues = _lib.get("ArtemisSetGpioValues", "cdecl")
    ArtemisSetGpioValues.argtypes = [ArtemisHandle, c_int]
    ArtemisSetGpioValues.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 982
for _lib in _libs.values():
    if not _lib.has("ArtemisGuide", "cdecl"):
        continue
    ArtemisGuide = _lib.get("ArtemisGuide", "cdecl")
    ArtemisGuide.argtypes = [ArtemisHandle, c_int]
    ArtemisGuide.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 989
for _lib in _libs.values():
    if not _lib.has("ArtemisGuidePort", "cdecl"):
        continue
    ArtemisGuidePort = _lib.get("ArtemisGuidePort", "cdecl")
    ArtemisGuidePort.argtypes = [ArtemisHandle, c_int]
    ArtemisGuidePort.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 997
for _lib in _libs.values():
    if not _lib.has("ArtemisPulseGuide", "cdecl"):
        continue
    ArtemisPulseGuide = _lib.get("ArtemisPulseGuide", "cdecl")
    ArtemisPulseGuide.argtypes = [ArtemisHandle, c_int, c_int]
    ArtemisPulseGuide.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1003
for _lib in _libs.values():
    if not _lib.has("ArtemisStopGuiding", "cdecl"):
        continue
    ArtemisStopGuiding = _lib.get("ArtemisStopGuiding", "cdecl")
    ArtemisStopGuiding.argtypes = [ArtemisHandle]
    ArtemisStopGuiding.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1010
for _lib in _libs.values():
    if not _lib.has("ArtemisStopGuidingBeforeDownload", "cdecl"):
        continue
    ArtemisStopGuidingBeforeDownload = _lib.get("ArtemisStopGuidingBeforeDownload", "cdecl")
    ArtemisStopGuidingBeforeDownload.argtypes = [ArtemisHandle, c_bool]
    ArtemisStopGuidingBeforeDownload.restype = c_int
    break

enum_HotPixelSensitivity = c_int# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1014

HPS_HIGH = 0# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1014

HPS_MEDIUM = (HPS_HIGH + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1014

HPS_LOW = (HPS_MEDIUM + 1)# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1014

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1021
for _lib in _libs.values():
    if not _lib.has("ArtemisHotPixelAutoRemoval", "cdecl"):
        continue
    ArtemisHotPixelAutoRemoval = _lib.get("ArtemisHotPixelAutoRemoval", "cdecl")
    ArtemisHotPixelAutoRemoval.argtypes = [ArtemisHandle, c_bool]
    ArtemisHotPixelAutoRemoval.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1033
for _lib in _libs.values():
    if not _lib.has("ArtemisHotPixelAdvancedRemoval", "cdecl"):
        continue
    ArtemisHotPixelAdvancedRemoval = _lib.get("ArtemisHotPixelAdvancedRemoval", "cdecl")
    ArtemisHotPixelAdvancedRemoval.argtypes = [ArtemisHandle, c_bool, c_bool, c_bool, enum_HotPixelSensitivity]
    ArtemisHotPixelAdvancedRemoval.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1043
for _lib in _libs.values():
    if not _lib.has("ArtemisHotPixelAdvancedStartCalculateHotPixels", "cdecl"):
        continue
    ArtemisHotPixelAdvancedStartCalculateHotPixels = _lib.get("ArtemisHotPixelAdvancedStartCalculateHotPixels", "cdecl")
    ArtemisHotPixelAdvancedStartCalculateHotPixels.argtypes = [ArtemisHandle, c_float]
    ArtemisHotPixelAdvancedStartCalculateHotPixels.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1049
for _lib in _libs.values():
    if not _lib.has("ArtemisHotPixelAdvancedCalculationComplete", "cdecl"):
        continue
    ArtemisHotPixelAdvancedCalculationComplete = _lib.get("ArtemisHotPixelAdvancedCalculationComplete", "cdecl")
    ArtemisHotPixelAdvancedCalculationComplete.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisHotPixelAdvancedCalculationComplete.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1058
for _lib in _libs.values():
    if not _lib.has("ArtemisGetLensAperture", "cdecl"):
        continue
    ArtemisGetLensAperture = _lib.get("ArtemisGetLensAperture", "cdecl")
    ArtemisGetLensAperture.argtypes = [ArtemisHandle, POINTER(c_int)]
    ArtemisGetLensAperture.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1065
for _lib in _libs.values():
    if not _lib.has("ArtemisGetLensFocus", "cdecl"):
        continue
    ArtemisGetLensFocus = _lib.get("ArtemisGetLensFocus", "cdecl")
    ArtemisGetLensFocus.argtypes = [ArtemisHandle, POINTER(c_int)]
    ArtemisGetLensFocus.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1075
for _lib in _libs.values():
    if not _lib.has("ArtemisGetLensLimits", "cdecl"):
        continue
    ArtemisGetLensLimits = _lib.get("ArtemisGetLensLimits", "cdecl")
    ArtemisGetLensLimits.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisGetLensLimits.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1082
for _lib in _libs.values():
    if not _lib.has("ArtemisInitializeLens", "cdecl"):
        continue
    ArtemisInitializeLens = _lib.get("ArtemisInitializeLens", "cdecl")
    ArtemisInitializeLens.argtypes = [ArtemisHandle]
    ArtemisInitializeLens.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1089
for _lib in _libs.values():
    if not _lib.has("ArtemisSetLensAperture", "cdecl"):
        continue
    ArtemisSetLensAperture = _lib.get("ArtemisSetLensAperture", "cdecl")
    ArtemisSetLensAperture.argtypes = [ArtemisHandle, c_int]
    ArtemisSetLensAperture.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1096
for _lib in _libs.values():
    if not _lib.has("ArtemisSetLensFocus", "cdecl"):
        continue
    ArtemisSetLensFocus = _lib.get("ArtemisSetLensFocus", "cdecl")
    ArtemisSetLensFocus.argtypes = [ArtemisHandle, c_int]
    ArtemisSetLensFocus.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1105
for _lib in _libs.values():
    if not _lib.has("ArtemisCanControlShutter", "cdecl"):
        continue
    ArtemisCanControlShutter = _lib.get("ArtemisCanControlShutter", "cdecl")
    ArtemisCanControlShutter.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisCanControlShutter.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1112
for _lib in _libs.values():
    if not _lib.has("ArtemisOpenShutter", "cdecl"):
        continue
    ArtemisOpenShutter = _lib.get("ArtemisOpenShutter", "cdecl")
    ArtemisOpenShutter.argtypes = [ArtemisHandle]
    ArtemisOpenShutter.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1119
for _lib in _libs.values():
    if not _lib.has("ArtemisCloseShutter", "cdecl"):
        continue
    ArtemisCloseShutter = _lib.get("ArtemisCloseShutter", "cdecl")
    ArtemisCloseShutter.argtypes = [ArtemisHandle]
    ArtemisCloseShutter.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1126
for _lib in _libs.values():
    if not _lib.has("ArtemisCanSetShutterSpeed", "cdecl"):
        continue
    ArtemisCanSetShutterSpeed = _lib.get("ArtemisCanSetShutterSpeed", "cdecl")
    ArtemisCanSetShutterSpeed.argtypes = [ArtemisHandle, POINTER(c_bool)]
    ArtemisCanSetShutterSpeed.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1133
for _lib in _libs.values():
    if not _lib.has("ArtemisGetShutterSpeed", "cdecl"):
        continue
    ArtemisGetShutterSpeed = _lib.get("ArtemisGetShutterSpeed", "cdecl")
    ArtemisGetShutterSpeed.argtypes = [ArtemisHandle, POINTER(c_int)]
    ArtemisGetShutterSpeed.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1140
for _lib in _libs.values():
    if not _lib.has("ArtemisSetShutterSpeed", "cdecl"):
        continue
    ArtemisSetShutterSpeed = _lib.get("ArtemisSetShutterSpeed", "cdecl")
    ArtemisSetShutterSpeed.argtypes = [ArtemisHandle, c_int]
    ArtemisSetShutterSpeed.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1151
for _lib in _libs.values():
    if not _lib.has("ArtemisTemperatureSensorInfo", "cdecl"):
        continue
    ArtemisTemperatureSensorInfo = _lib.get("ArtemisTemperatureSensorInfo", "cdecl")
    ArtemisTemperatureSensorInfo.argtypes = [ArtemisHandle, c_int, POINTER(c_int)]
    ArtemisTemperatureSensorInfo.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1159
for _lib in _libs.values():
    if not _lib.has("ArtemisSetCooling", "cdecl"):
        continue
    ArtemisSetCooling = _lib.get("ArtemisSetCooling", "cdecl")
    ArtemisSetCooling.argtypes = [ArtemisHandle, c_int]
    ArtemisSetCooling.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1167
for _lib in _libs.values():
    if not _lib.has("ArtemisSetCoolingPower", "cdecl"):
        continue
    ArtemisSetCoolingPower = _lib.get("ArtemisSetCoolingPower", "cdecl")
    ArtemisSetCoolingPower.argtypes = [ArtemisHandle, c_int]
    ArtemisSetCoolingPower.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1178
for _lib in _libs.values():
    if not _lib.has("ArtemisCoolingInfo", "cdecl"):
        continue
    ArtemisCoolingInfo = _lib.get("ArtemisCoolingInfo", "cdecl")
    ArtemisCoolingInfo.argtypes = [ArtemisHandle, POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int), POINTER(c_int)]
    ArtemisCoolingInfo.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1185
for _lib in _libs.values():
    if not _lib.has("ArtemisCoolerWarmUp", "cdecl"):
        continue
    ArtemisCoolerWarmUp = _lib.get("ArtemisCoolerWarmUp", "cdecl")
    ArtemisCoolerWarmUp.argtypes = [ArtemisHandle]
    ArtemisCoolerWarmUp.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1192
for _lib in _libs.values():
    if not _lib.has("ArtemisGetWindowHeaterPower", "cdecl"):
        continue
    ArtemisGetWindowHeaterPower = _lib.get("ArtemisGetWindowHeaterPower", "cdecl")
    ArtemisGetWindowHeaterPower.argtypes = [ArtemisHandle, POINTER(c_int)]
    ArtemisGetWindowHeaterPower.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1199
for _lib in _libs.values():
    if not _lib.has("ArtemisSetWindowHeaterPower", "cdecl"):
        continue
    ArtemisSetWindowHeaterPower = _lib.get("ArtemisSetWindowHeaterPower", "cdecl")
    ArtemisSetWindowHeaterPower.argtypes = [ArtemisHandle, c_int]
    ArtemisSetWindowHeaterPower.restype = c_int
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1207
for _lib in _libs.values():
    if not _lib.has("ArtemisLoadDLL", "cdecl"):
        continue
    ArtemisLoadDLL = _lib.get("ArtemisLoadDLL", "cdecl")
    ArtemisLoadDLL.argtypes = [String]
    ArtemisLoadDLL.restype = c_bool
    break

# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 1213
for _lib in _libs.values():
    if not _lib.has("ArtemisUnLoadDLL", "cdecl"):
        continue
    ArtemisUnLoadDLL = _lib.get("ArtemisUnLoadDLL", "cdecl")
    ArtemisUnLoadDLL.argtypes = []
    ArtemisUnLoadDLL.restype = None
    break

ARTEMISPROPERTIES = struct_ARTEMISPROPERTIES# /mnt/c/Atik/C++/DLLBranches/Working/AtikCamerasDLLExample/include/Windows/AtikCameras.h: 189

# No inserted files

# No prefix-stripping

#endregion

import time
from enum import Enum
from enum import IntEnum
import numpy as np

class CMOSOptions(Enum):
    """!ID's for the camera specific options."""
    ID_GOPresetMode     = 1
    ID_GOPresetLow      = 2
    ID_GOPresetMed      = 3 
    ID_GOPresetHigh     = 4  
    ID_GOCustomGain     = 5
    ID_GOCustomOffset   = 6
    ID_EvenIllumination = 12
    ID_PadData          = 13
    ID_ExposureSpeed    = 14
    ID_BitSendMode      = 15
    ID_16BitMode        = 18
    ID_ReadoutModeTE    = 20
    ID_ADC1OffsetTE     = 88
    ID_FX3Version       = 200
    ID_FPGAVersion      = 201

class CameraState(Enum):
    """!Flags for the Camera State."""
    Camera_Error = (-1)
    Idle         = 0
    Waiting      = 1
    Exposing     = 2
    Reading      = 3
    Downloading  = 4
    Flushing     = 5

class ConnectionState(Enum):
    """!Flags for the camera connection state.
    @see camera_connection_state()."""
    Connecting          = 1
    Connected           = 2
    Connect_Failed      = 3
    Suspended           = 4
    Connection_Unknown  = 5

class ColourType(Enum):
    """!Camera colour properties"""
    Unknown = 0
    Mono    = 1
    Colour  = 2

class EFWType(IntEnum):
    """!Filter wheel type.
    @note An EFW3 will show as EFW2 as they use the same firmware.
    @see efw_device_details."""
    EFW1 = 1
    EFW2 = 2

class ExposureSpeed(IntEnum):
    """!Camera exposure speed."""
    PowerSave = 0
    Normal    = 1
    Fast      = 2

class ReadoutModeTE(IntEnum):
    """!TE Series readout mode."""
    LowestNoise = 0
    LowNoise    = 1
    Preview     = 2

class SixteenBitMode(IntEnum):
    """!Camera sixteen bit mode."""
    Off               = 0
    Stretch           = 1
    CombinedExposure = 2
    CombinedGain     = 3

class CoolingInfo(IntEnum):
    """!Index into ArtemisCoolingInfo() flags.
    @see cooling_info()."""
    HasCooling             = 1
    Controllable            = 2
    OnOffCooling_Control  = 4
    PowerLevelControl     = 8
    SetPointControl       = 16
    WarmingUp              = 32
    CoolingOn              = 64
    SetPointControlOn    = 128

class PrechargeMode(Enum):
    """!Flags for precharge mode.
    @see precharge_mode()."""
    Ignored = 0
    ICPS    = 1
    Full    = 2

class ProcessingInfo(IntEnum):
    """!Flags for ArtemisGet/SetProcessing 
    @see get_processing(), set_processing()."""
    Linearise               = 1
    VenetianBlindEffect   = 2

class CameraError(Exception):
    """!Exception raise based on return code from calling the C SDK functions."""

    error_strings = {
        0: "ARTEMIS_OK",
        1: "ARTEMIS_INVALID_PARAMETER",
        2: "ARTEMIS_NOT_CONNECTED",
        3: "ARTEMIS_NOT_IMPLEMENTED",
        4: "ARTEMIS_NO_RESPONSE",
        5: "ARTEMIS_INVALID_FUNCTION",
        6: "ARTEMIS_NOT_INITIALIZED",
        7: "ARTEMIS_OPERATION_FAILED",
    }
    
    def __init__(self, error):
        t = type(error)
        
        if t is bool:
            self.boolean_code = error
        elif t is int:
            self.error_code = error

    def __str__(self):
        if hasattr(self, "boolean_code"):
            error_desc = "Function returned false"
        elif hasattr(self, "error_code"):
            error_desc = self.error_strings.get(self.error_code, "Unrecognised ARTEMISERROR")
        else:
            error_desc = "Unknown error"

        return f"Error communicating with SDK: {error_desc}"

class AtikSDKCamera:
    """!Convenience class for using Atik devices."""

#region Init

    def __init__(self):
        """!Constructs an AtikSDKCamera instance. Note that one must connect() to the camera before using it"""

        self._handle = None

    def __del__(self):
        """!Deletes an AtikSDKCamera instance. Also disconnects from the camera, if connected."""

        self.disconnect()

    def _check_connected(func):
        """!Use this as a decorator for functions which require a valid handle to function."""

        def wrapper(self, *args, **kwargs):
            if not self.is_connected():
                raise Exception("Camera is not connected. Use the connect() method to connect to the camera first.")
            
            return func(self, *args, **kwargs)

        return wrapper

    def connect(self, camera_index: int=0):
        """!Connects to an Atik camera. Wait until FPGA is uploaded before connecting
        @param camera_index The connected Atik camera index to connect to. This is 0 for the first connected camera"""

        attempts = 0

        while not ArtemisDeviceIsPresent(camera_index):
            time.sleep(0.1)
            attempts += 1

            if attempts > 10:
                raise Exception(f"Could not detect Atik Camera at index {camera_index}")

        self._handle = ArtemisConnect(camera_index)

        if not self._handle:
            raise Exception(f"Could not connect to Atik Camera at index {camera_index}")

    def disconnect(self):
        """!Disconnects from the camera."""

        if self.is_connected():
            ArtemisDisconnect(self._handle)

    def is_connected(self) -> bool:
        """!Checks whether the camera has been connected to
        @returns True if connected successfully, False otherwise"""

        return bool(self._handle)

#endregion

#region Dll

    def get_api_version(self):
        """!Get API Version, may be the same as DLL version.
        @returns API version as integer."""
        ver = ArtemisAPIVersion()
        return ver

    def get_dll_version(self):
        """!Get DLL Version, may be the same as API version.
        @returns DLL version as integer."""
        dll = ArtemisDLLVersion()
        return dll
    
    def is_local_connection(self):
        """!Returns if the camera connection is local.
        @returns True is connection is local (E.G through USB cable), False otherwise."""

        return bool(ArtemisIsLocalConnection())
    
    def debug_to_console(self, enable:bool):
        """!Allow debug output be output as standard error.
        @param enable Whether to enable the output."""
        
        ArtemisAllowDebugToConsole(self, enable)

    def shutdown(self):
        """!Deallocates all internal DLL structures."""
        ArtemisShutdown()
    
#endregion

#region Device

    def device_count(self):
        """!Returns number of connected and recognised devices, count doesn't include misconfigured devices.
        @returns Number of connected and recognised devices as int"""

        return int(ArtemisDeviceCount())
    
    def is_device_present(self, device:int):
        """!Checks if the device is at the index is connected.
        @param device Index of the device being queried. This is 0 for the first connected device.
        @returns True if device is present, False otherwise."""

        return bool(ArtemisDevicePresent(device))
    
    def device_in_use(self, device:int):
        """!Checks if the device is already connected to.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns True if the device has an attached handle, False otherwise."""

        return bool(ArtemisDeviceInUse(device))
    
    def get_device_name(self, device:int):
        """!Retrieves device's name.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns Device name as string."""
        
        name = create_string_buffer(100)
        ArtemisDeviceName(device, name)

        pName = name.raw.decode("utf-8")
        return pName
        
    def get_device_serial(self, device:int):
        """!Retrieves device's serial.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns Device serial number as string."""
        
        serial = create_string_buffer(100)
        ArtemisDeviceSerial(device, serial)

        pSerial = serial.raw.decode("utf-8")
        return pSerial
    
    def device_is_camera(self, device:int):
        """!Return whether device at specified index is a camera.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns True if device is camera, False otherwise."""

        return bool(ArtemisDeviceIsCamera(device))

    def device_has_filterwheel(self, device:int):
        """!Return if the device at specified index has a filterwheel.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns True if the device has filterwheel, False otherwise."""

        return bool(ArtemisDeviceHasFilterWheel(device))
    
    def device_has_guideport(self, device:int):
        """!Return whether the device at the specified index has a guide port.
        @param device Index of device being queried. This is 0 for the first connected device.
        @returns True if device has guide port, False otherwise."""

        return bool(ArtemisDeviceHasGuidePort(device))
    
    def refresh_device_count(self):
        """!Updates the available devices."""
        ArtemisRefreshDevicesCount()

#endregion

#region CameraInfo

    @_check_connected
    def get_serial(self):
        """!Gets the connected camera's serial number.
        @returns The camera's serial number as int."""

        flags = c_int(0)
        serial = c_int(0)

        result = ArtemisCameraSerial(self._handle, byref(flags), byref(serial))

        if(result == ARTEMIS_INVALID_FUNCTION):
            print("Please use get_serial_str rather than get_serial. The serial number of this camera may contain characters.")

        if result != ARTEMIS_OK:
            raise CameraError(result)

        return serial.value

    @_check_connected
    def get_serial_str(self):
        """!Gets the connected camera's serial number.
        @returns The camera's serial number as a string."""

        pSerial = c_char_p() 
        result = ArtemisCameraSerialEx(self._handle, pSerial)

        if result != ARTEMIS_OK:
            raise CameraError(result)

        return pSerial.value.decode('UTF-8')
    
    @_check_connected
    def get_colour_properties(self):
        """!Retrieves the colour properties of the device.
        @returns Camera colour type, Normal offset over X axis, Normal offset over Y axis,
        Preview offset over X axis, Preview offset over Y axis."""
        
        colour = enum_ARTEMISCOLOURTYPE()
        normalOffsetX = c_int()
        normalOffsetY = c_int()
        previewOffX = c_int()
        previewOffY = c_int()

        result = ArtemisColourProperties(self._handle, byref(colour), byref(normalOffsetX), byref(normalOffsetY), byref(previewOffX), byref(previewOffY))

        if result != ARTEMIS_OK:
            raise CameraError(result)
        
        return ColourType(colour.value), normalOffsetX.value, normalOffsetY.value, previewOffX.value, previewOffY.value
        
    @_check_connected
    def get_properties(self):
        """!Returns the connected camera's properties.
        @returns A dictionary of camera properties, including native sensor width and height, camera name and manufacturer."""

        props = ARTEMISPROPERTIES()
        result = ArtemisProperties(self._handle, byref(props))
        
        if result != ARTEMIS_OK:
            raise CameraError(result)

        props_dict = dict((field, getattr(props, field)) for field, _ in props._fields_)
     
        return props_dict
    
    @_check_connected
    def camera_connection_state(self):
        """!Gets the current cameras connection state."""

        state = enum_ARTEMISCAMERASTATE()
        result = ArtemisCameraConnectionState(self._handle, byref(state))

        if result != ARTEMIS_OK:
            raise CameraError(result)

        return ConnectionState(state.value)
    
    def internal_filterwheel_info(self):
        """!Gets information of the connected filter wheel.
        @returns Number of filters, whether the wheel is moving and the current filter wheel position."""

        props = self.get_properties()
        cameraFlags = props["cameraflags"]
        hasFilterWheel = (cameraFlags | ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_FILTERWHEEL) == ARTEMIS_PROPERTIES_CAMERAFLAGS_HAS_FILTERWHEEL

        numOfFilters = c_int()
        moving = c_int()
        currentPos = c_int()
        targetPos = c_int()
        if (hasFilterWheel):
            res = ArtemisFilterWheelInfo(self._handle, byref(numOfFilters), byref(moving), byref(currentPos), byref(targetPos))

            if res != ARTEMIS_OK:
                raise CameraError(res)
        else:
            raise CameraError(ARTEMIS_INVALID_FUNCTION)
        
        return (numOfFilters.value, bool(moving.value), currentPos.value)    
    
    def move_internal_filterwheel(self, target:int):
        """!Move the cameras internal filterwheel.
        @param target The target filter wheel position to move to."""

        res = ArtemisFilterWheelMove(self._handle, target)
        if res != ARTEMIS_OK:
            raise CameraError(res)

#endregion

#region ExposureSettings

    @_check_connected
    def set_binning(self, binX: int, binY: int):
        """!Sets the binning of the camera. This will decrease the output resolution accordingly.
        @param binX The horizontal binning value.
        @param binY The vertical binning value."""

        res = ArtemisBin(self._handle, binX, binY)

        if res != ARTEMIS_OK:
            raise CameraError(res)


    @_check_connected
    def get_binning(self):
        """!Gets the binning for the device.
        @returns Current binning value on both X and Y axis as int."""

        binX = c_int()
        binY = c_int()

        res = ArtemisGetBin(self._handle, byref(binX), byref(binY))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return binX.value, binY.value
    
    @_check_connected
    def get_max_bin(self):
        """!Retrieves the maximum binning supported by the device.
        @returns Maximum bining values for both X and Y axis as int."""

        maxBinX = c_int()
        maxBinY = c_int()

        res = ArtemisGetMaxBin(self._handle, byref(maxBinX), byref(maxBinY))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return maxBinX.value, maxBinY.value
    
    @_check_connected
    def get_subframe(self):
        """!Retrieves the current subframing settings for the device.
        @returns Current subframing values for both X and Y axis, width and height as int."""

        offX = c_int()
        offY = c_int()
        width = c_int()
        height = c_int()

        res = ArtemisGetSubframe(self._handle, byref(offX), byref(offY), byref(width), byref(height))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return offX.value, offY.value, width.value, height.value

    @_check_connected
    def set_subframe(self, x: int, y: int, w: int, h: int):
        """!Sets the position and size of the subframe captured, in unbinned pixel sizes.
        @param x The starting x pixel co-ordinate.
        @param y The starting y pixel co-ordinate.
        @param w The width of subframe.
        @param h The height of subframe."""
        xcoord = c_int(x)
        ycoord = c_int(y)
        wcoord = c_int(w)
        hcoord = c_int(h)
        
        result = ArtemisSubframe(self._handle, xcoord, ycoord, wcoord, hcoord)

        if result != ARTEMIS_OK:
            raise CameraError(result)
        
    @_check_connected
    def set_subframe_position(self, x:int, y:int):
        """!Sets the device's subframe position.
        @param x The X offset of the subframe region.
        @param y The Y offset of the subframe region."""

        res = ArtemisSubframePos(self._handle, x, y)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def set_subframe_size(self, w:int, h:int):
        """!Sets the device's subframe width and height.
        @param w The width of the subframe region.
        @param h The height of the subframe region."""

        res = ArtemisSubframeSize(self._handle, w, h)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def set_subframe_sample(self, isOn:bool):
        """!Sets whether subsampling mode is enabled on the device.
        @param isOn Whether to enable or disable subsampling mode."""

        res = ArtemisSetSubSample(self._handle, isOn)
        if res!= ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def continuous_mode_supported(self):
        """!Retrieves whether continuous exposing is supported by the device. Titan camera only.
        @returns True if supported, False otherwise."""

        return bool(ArtemisContinuousExposingModeSupported(self._handle))
    
    @_check_connected
    def get_continuous_exposure(self):
        """!Retrieves whether continuous exposing is enabled for the device. Titan camera only.
        @returns True if continuous mode is enabled, False otherwise."""
        
        return bool(ArtemisGetContinuousExposingMode(self._handle))

    @_check_connected
    def set_continuous_mode(self, enable:bool):
        """!Sets whether continous exposing mode is enabled. Titan camera only.
        @param enable Whether to enable or disable continuous mode."""

        if ArtemisContinuousExposingModeSupported(self._handle) == True:
            res = ArtemisSetContinuousExposingMode(self._handle, enable)
            if res != ARTEMIS_OK:
                raise CameraError(res)
    
    @_check_connected
    def get_dark_mode(self):
        """!Retrieves whether dark mode is enabled for the device.
        @returns True if dark mode is enabled, False otherwise."""
 
        return bool(ArtemisGetDarkMode(self._handle))
    
    @_check_connected
    def set_dark_mode(self, enable:bool):
        """!Sets the camera into Dark Mode if available.
        @param enable Whether to enable or disable dark mode."""

        error = ArtemisSetDarkMode(self._handle, enable)

        if error != ARTEMIS_OK:
            raise CameraError(error)
        
    @_check_connected
    def set_preview(self, enable:bool):
        """!Sets whether preview mode is enabled for the device.
        If preview mode is enabled, the sensor is not cleared between exposures.
        Using preview mode, there might be more noise/glow in the resulting image.
        @param enable Whether to enable or disable preview mode."""

        res = ArtemisSetPreview(self._handle, enable)
        if res != ARTEMIS_OK:
            raise CameraError(res)

    
    @_check_connected
    def auto_adjust_black_level(self, enable:bool):
        """!Sets if the black level will be auto adjusted.
        @param enable Bool setting if the black level will be auto adjusted."""

        res = ArtemisAutoAdjustBlackLevel(self._handle, enable)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def precharge_mode(self, mode:int):
        """!Sets the precharge mode of the camera. Applies and in-camera offset. Mainly for astronomy use.
        @param mode 0 = Ignored, 1 = IPCS, 2 = Full."""

        res = ArtemisPrechargeMode(self._handle, mode)
        if res != ARTEMIS_OK:
            raise CameraError(res)   

    @_check_connected
    def eight_bit_mode(self, setEightBit:bool):
        """!Sets whether 8-bit mode is enabled on the device.
        This affects size of returned image buffer, by default is 16 bits.
        @param setEightBit Whether to enable 8-bit mode."""

        res = ArtemisEightBitMode(self._handle, setEightBit)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def get_eight_bit_mode(self):
        """!Retrieves whether 8-bit mode is enabled on the device.
        @returns True if eight bit mode is enabled, False otherwise."""

        isEnabled = c_bool()

        return bool(ArtemisGetEightBitMode(self._handle, byref(isEnabled)))
    
    @_check_connected
    def start_overlapped_exposure(self):
        """!Begin an overlapped exposure."""

        res = ArtemisStartOverlappedExposure(self._handle)
        if res != ARTEMIS_OK:
            raise Exception("res")
    
    @_check_connected
    def overlapped_exposure_valid(self):
        """!Returns whether the overlapped exposure is still valid.
        @returns True if valid, False otherwise."""
      
        return bool(ArtemisOverlappedExposureValid(self._handle))
    
    @_check_connected
    def set_overlapped_exposure_time(self, seconds:float):
        """!Set the overlapped exposure time.
        @param seconds Floating point number of seconds for overlapped exposure."""

        res = ArtemisSetOverlappedExposureTime(self._handle, seconds)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def set_triggered_exposure(self, enable:bool):
        """! Sets the camera into triggered exposure mode. This mode is only available on cameras that have a physical trigger in.
        @param enable Sets whether the trigger mode is enabled."""

        error = ArtemisTriggeredExposure(self._handle, enable)        
        if error != ARTEMIS_OK:
            raise CameraError(error)

    @_check_connected
    def get_processing(self):
        """!Return which post processing flags are enabled for the device.
        @returns Enumeration of flags enabled for the device."""

        res = ArtemisGetProcessing(self._handle)

        flags = c_int(res)
        flagsList = []

        for enum in ProcessingInfo:
            if flags.value > 0:
                if enum < flags.value:
                    flagsList.append(enum)
                return flagsList
            else:
                return flags.value
    
    @_check_connected
    def set_processing(self, options:int):
        """!Sets which post processing effects are enabled for the device.
        @param options 1 = Linearise, 2 = Venetian Blind Effect (VBE)."""
        
        res = ArtemisSetProcessing(self._handle, options)
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def get_auto_exposure_length(self, percentile : int, adu : int, startingExposureLength: float, minExposureLength: float, maxExposureLength:float) -> float:
        """!Returns an exposure length where by the passed adu value and values below will occupy the percentile passed."""

        exposureLength = c_float(1.0)
        cpercentile = c_int(percentile)
        cadu = c_uint16(adu)
        cstartingExposureLength = c_float(startingExposureLength)
        cminExposureLength = c_float(minExposureLength)
        cmaxExposureLength = c_float(maxExposureLength)

        error = ArtemisAutoExposureLength(self._handle, cpercentile, cadu, byref(exposureLength), cstartingExposureLength, cminExposureLength, cmaxExposureLength)

        if exposureLength == -1 or exposureLength == -2 or error == 0:
            return np.float32(exposureLength)
        else:
            raise CameraError(error)

#endregion

#region Exposure

    @_check_connected
    def start_exposure(self, exposure_time:float):
        """!Starts an exposure. Returns immediately. Use image_ready()
        to check if the exposure has finished and the image data has
        been downloaded. Then use get_image() to retrieve the image.
        @param exposure_time The exposure time as a float in seconds."""

        error = ArtemisStartExposure(self._handle, exposure_time)
        if error != ARTEMIS_OK:
            raise CameraError(error)

    @_check_connected
    def start_exposure_ms(self, exposure_time_ms:int):
        """!Starts an exposure. Returns immediately. Use image_ready()
        to check if the exposure has finished and the image data has
        been downloaded. Then use get_image() to retrieve the image.
        @param exposure_time_ms The exposure time as an integer in milliseconds."""

        error = ArtemisStartExposureMS(self._handle, exposure_time_ms)

        if error != ARTEMIS_OK:
            raise CameraError(error)

    @_check_connected
    def image_ready(self):
        """!Returns true if there is an image available.
        @returns true if an image is ready, returns false if an exposure is in progress."""
        return ArtemisImageReady(self._handle)

    @_check_connected
    def get_image(self):
        """!Returns image data in a NumPy array.
        @returns numpy 16 bits per pixel ndarray of the image taken."""
        x, y, w, h, bx, by = c_int(), c_int(), c_int(), c_int(), c_int(), c_int() 
        error = ArtemisGetImageData(self._handle, byref(x), byref(y), byref(w), byref(h), byref(bx), byref(by))

        if error != ARTEMIS_OK:
            raise CameraError(error)
            
        image_buffer = ArtemisImageBuffer(self._handle)

        if not image_buffer:
            raise CameraError(False)

        raw_string = string_at(image_buffer, w.value * h.value * 2)
        
        arr = np.fromstring(raw_string, dtype=np.uint16, count=w.value * h.value)
        arr = arr.reshape(h.value, w.value)

        return arr

    @_check_connected
    def take_image(self, exposure_time:float):
        """!Takes an image with the specified exposure time.
        This function blocks until the exposure has been taken and downloaded.
        @param exposure_time Sets the exposure time, in seconds.
        @returns numpy 16 bits per pixel ndarray of the image taken."""

        error = ArtemisStartExposure(self._handle, exposure_time)

        if error != ARTEMIS_OK:
            raise CameraError(error)

        time.sleep(exposure_time)

        while not ArtemisImageReady(self._handle):
            time.sleep(0.001)

        x, y, w, h, bx, by = c_int(), c_int(), c_int(), c_int(), c_int(), c_int() 
        error = ArtemisGetImageData(self._handle, byref(x), byref(y), byref(w), byref(h), byref(bx), byref(by))

        if error != ARTEMIS_OK:
            raise CameraError(error)

        image_buffer = ArtemisImageBuffer(self._handle)

        if not image_buffer:
            raise CameraError(False)

        raw_string = string_at(image_buffer, w.value * h.value * 2)
        
        arr = np.fromstring(raw_string, dtype=np.uint16, count=w.value * h.value)
        arr = arr.reshape(h.value, w.value)

        return arr
    
    @_check_connected
    def take_image_ms(self, exposure_time_ms:int):
        """!Takes an image with the specified exposure time in ms.
        This function blocks until the exposure has been taken and downloaded.
        @param exposure_time_ms Sets the exposure time, as milliseconds.
        @returns numpy 16 bits per pixel ndarray of the image taken."""

        error = ArtemisStartExposureMS(self._handle, exposure_time_ms)

        if error != ARTEMIS_OK:
            raise CameraError(error)

        time.sleep(exposure_time_ms/1000)

        while not ArtemisImageReady(self._handle):
            time.sleep(0.001)

        x, y, w, h, bx, by = c_int(), c_int(), c_int(), c_int(), c_int(), c_int() 
        error = ArtemisGetImageData(self._handle, byref(x), byref(y), byref(w), byref(h), byref(bx), byref(by))

        if error != ARTEMIS_OK:
            raise CameraError(error)

        image_buffer = ArtemisImageBuffer(self._handle)

        if not image_buffer:
            raise CameraError(False)

        raw_string =string_at(image_buffer, w.value * h.value * 2)
        
        arr = np.fromstring(raw_string, dtype=np.uint16, count=w.value * h.value)
        arr = arr.reshape(h.value, w.value)

        return arr
    
    @_check_connected
    def stop_exposure(self):
        """!When called this function will stop the fast exposure process."""
        try:
            return ArtemisStopExposure(self._handle)
        except CameraError as e:
            raise Exception("set_fast_callback() unsupported for this camera type")
    
    @_check_connected
    def camera_state(self):
        """!Gets the current camera exposure state."""

        return CameraState(ArtemisCameraState(self._handle))
    
    @_check_connected
    def exposure_time_remaining(self):
        """!Gets time left on the exposure as a floating point number.
        @returns The number of seconds remaining in the exposure as a floating point number."""
        
        return ArtemisExposureTimeRemaining(self._handle)
    
    @_check_connected
    def download_percent(self):
        """!Returns the download progress in percent.
        @returns The download progress in percent (0-100)."""

        return int(ArtemisDownloadPercent(self._handle))
    
    @_check_connected
    def get_image_data(self):
        """!Provides information about the latest acquired image.
        @returns Subframe size on X axis, Subframe size on Y axis, Width of image in pixels, Height of image in pixels, 
        Horizontal binning value, Vertical binning value."""

        xAxis = c_int()
        yAxis = c_int()
        width = c_int()
        height = c_int()
        binX = c_int()
        binY = c_int()

        res = ArtemisGetImageData(self._handle, byref(xAxis), byref(yAxis), byref(width), byref(height), byref(binX), byref(binY))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return xAxis.value, yAxis.value, width.value, height.value, binX.value, binY.value
    
    @_check_connected
    def last_exposure_duration(self):
        """!Returns the duration of the last exposure as a floating point number of seconds.
        @returns The duration of the last exposure as a floating point of seconds."""

        return float((ArtemisLastExposureDuration(self._handle)))

    @_check_connected
    def get_last_exposure_start_time(self):
        """!Returns the last exposure start time with millisecond component."""

        time = ArtemisLastStartTime(self._handle).data.decode('UTF-8')
        milliseconds = ArtemisLastStartTimeMilliseconds(self._handle)

        return f"{time}.{milliseconds}"

    @_check_connected
    def has_fast_mode(self):
        """!Checks if the connected camera can run in fast mode.
        @returns True if fast mode supported, False otherwise."""
        try:
            return ArtemisHasFastMode(self._handle)
        except CameraError as e:
            raise Exception("has_fast_mode() unsupported for this camera type")
        
    @_check_connected
    def start_fast_exposure(self, exposure_time_ms):
        """!Will start a fast exposure session for our HorizonII/ACIS/APX series cameras."""
        try:
            ArtemisStartFastExposure(self._handle, exposure_time_ms)
        except CameraError as e:
            raise Exception("start_fast_exposure() unsupported for this camera type")

    @_check_connected
    def set_fast_callback(self, FastCallback):
        """!Sets up the function to be called on a successful fast mode image. 
        The FastCallback passed here will be called every time there is a new image.
        We recommend doing as little processing in the passed function as possible as this
        function will block execution of our internal exposure thread."""
        try:
            return ArtemisSetFastCallback(self._handle, FastCallback)
        except CameraError as e:
            raise Exception("set_fast_callback() unsupported for this camera type")
        
#endregion

#region Amplifier

    @_check_connected
    def set_amplifier(self, enable:bool):
        """!Enable/disable the device's amplifier.
        @param enable Whether to enable or disable the built in amplifier."""

        isEnabled = ArtemisAmplifier(self._handle, enable)
        if isEnabled != ARTEMIS_OK:
            raise CameraError(isEnabled)

    @_check_connected
    def get_amplifier(self):
        """!Returns whether the amplifier is enabled.
        @returns True if enabled, False otherwise."""

        return bool(ArtemisGetAmplifierSwitched(self._handle))
        
#endregion

#region CameraSpecificOptions

    @_check_connected
    def get_gain_offset_range(self):
        """! Gets the minimum and maximum range of values that can be set for both the gain and offset
        for our CMOS cameras (Horizon/II, ACIS) while in custom gain mode
        @returns A tuple containing(in this order) the minimum camera gain, maximum camera gain, minimum camera offset and maximum camera offset"""
        result = bool(ArtemisHasCameraSpecificOption(self._handle, CMOSOptions.ID_GOPresetMode.value))
        
        if result == False:
            raise CameraError(5) # Cannot set custom gain/offset on this camera return Invalid Function
        actual_length = (c_int)(0)
        gain_range = (c_ubyte * 6)()
        
        ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomGain.value, gain_range, 6, byref(actual_length))

        gain_min = gain_range[0] + (gain_range[1] << 8)
        gain_max = gain_range[2] + (gain_range[3] << 8)

        offset_range = (c_ubyte * 6)()
        ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, offset_range, 6, byref(actual_length))

        offset_min = offset_range[0] + (offset_range[1] << 8)
        offset_max = offset_range[2] + (offset_range[3] << 8)

        return (gain_min, gain_max, offset_min, offset_max)

    @_check_connected
    def set_gain_offset(self, gain, offset):
        """! Sets the gain and offset for the current camera.
        @param gain The gain to set
        @param offset The offset/blacklevel to set """

        # CCD: Set Gain
        # Not exposing IsPreview for now. Do we want to expose it?
        try:
            res = ArtemisSetGain(self._handle, False, gain, offset)
        except CameraError as e:
            # TODO check error code
            pass

        try:          
            # Standard SetGain hasn't worked let's try CMOS gain

            actual_length = (c_int)(0)
            preset_mode = (c_ubyte * 2)()
            ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOPresetMode.value, preset_mode, 2, byref(actual_length))

            gain_offset_mode = (c_ubyte * 2)(0)
            ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_GOPresetMode.value, gain_offset_mode, 2) # Set to custom

            local_gain = (c_ubyte * 2)(gain, gain >> 8)
            ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_GOCustomGain.value, local_gain, 2)
            
            local_offset = (c_ubyte * 2)(offset, offset >> 8)
            ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, local_offset, 2)

        except CameraError as e:
            # TODO check error code
            raise Exception("set_gain_offset() unsupported for this camera type")


    @_check_connected
    def get_gain_offset(self):
        """! Gets the gain and offset for the current camera.
        @returns A tuple containing(in this order) the current gain, and the current"""

        current_gain = c_int()
        current_offset = c_int()

        # Get CCD gain
        try:
            res = ArtemisGetGain(self._handle, False, byref(current_gain), byref(current_offset))   
            if res == 0:
                return (current_gain.value, current_offset.value)
            
        except CameraError as e:
            # CMOS camera, continue
            pass

        try:
            actual_length = (c_int)(0)
            preset_mode = (c_ubyte * 2)()
            ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOPresetMode.value, preset_mode, 2, byref(actual_length))

            preset_mode = int.from_bytes(preset_mode, "little")
            actual_length = (c_int)(0)
            gain = (c_ubyte * 6)()
            offset = (c_ubyte * 6)()

            if preset_mode == 0:
                # custom
                ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomGain.value, gain, 6, byref(actual_length))
                ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, offset, 6, byref(actual_length))
            elif preset_mode == 1:
                # low
                ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOPresetLow.value, gain, 5, byref(actual_length))
            elif preset_mode == 2:
                # medium
                ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOPresetMed.value, gain, 5, byref(actual_length))
            elif preset_mode == 3:
                # high
                ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOPresetHigh.value, gain, 5, byref(actual_length))

            if actual_length.value == 6:
                # as ushort range
                # min value, max value, current value, as ushort
                gain = int.from_bytes(gain[4:6], "little")
                offset = int.from_bytes(offset[4:6], "little")
            elif actual_length.value == 5:
                # presets
                # camera has preset byte, gain ushort, offset ushort
                gain = int.from_bytes(gain[1:3], "little")
                offset = int.from_bytes(gain[3:5], "little")
            else:
                # plain ushort
                gain = int.from_bytes(gain, "little")
                offset = int.from_bytes(offset, "little")

            return (gain, offset)
        except CameraError as e:
            raise Exception("get_gain_offset() unsupported for this camera type")

    @_check_connected
    def has_pad_data(self):
        """! Returns whether the camera has the pad data capability"""
        try:
            return ArtemisHasCameraSpecificOption(self._handle, CMOSOptions.ID_PadData.value)
        except CameraError as e:
            raise Exception("has_pad_data() unsupported for this camera type")

    @_check_connected
    def get_pad_data(self):
        """! Returns whether pad data is enabled."""
        try:
            actual_length = (c_int)(0)
            pad_data = (1 * c_ubyte)()

            ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_PadData.value, pad_data, 1, byref(actual_length))

            pad_data = int.from_bytes(pad_data, "little")
            return pad_data
        except CameraError as e:
            raise Exception("get_pad_data() unsupported for this camera type")


    @_check_connected
    def set_pad_data(self, on):
        """! Turns on/off pad data for our 12bit CMOS cameras (Horizon/II, ACIS)
        With pad data on we shift the lower 12bits of each pixel up by 4 into the top 12bits (this will leave the lowest four bits empty)
        @param on Turns PadData on or off """

        result = bool(ArtemisHasCameraSpecificOption(self._handle, CMOSOptions.ID_PadData.value))

        if result == False:
            raise CameraError(5) # Cannot set pad data on this camera return Invalid Function

        local_on = (c_ubyte * 2)()
        local_on[0] = c_ubyte(on)

        ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_PadData.value, local_on, 2)

    @_check_connected
    def get_exposure_speed(self):
        """! Retrieves the current exposure speed from our Horizon/ACIS/APX/TE series cameras"""
        try:
            actual_length = (c_int)(0)
            exp_speed = (2 * c_ubyte)()

            ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_ExposureSpeed.value, exp_speed, 2, byref(actual_length))

            exp_speed = int.from_bytes(exp_speed, "little")
            exp_speed_enum = ExposureSpeed(exp_speed)
            return exp_speed_enum
        except CameraError as e:
            raise Exception("get_exposure_speed() unsupported for this camera type")

    @_check_connected
    def set_exposure_speed(self, exposure_speed_enum : ExposureSpeed):
        """! Sets the current exposure speed for our Horizon/ACIS/APX/TE series cameras"""
        try:
            exposure_speed = int(exposure_speed_enum)
            local_exp_speed = (c_ubyte * 2)(exposure_speed, exposure_speed >> 8)

            ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_ExposureSpeed.value, local_exp_speed, 2)
        except CameraError as e:
            raise Exception("set_exposure_speed() unsupported for this camera type")
        
    @_check_connected
    def get_te_readout_mode(self):
        """! Retrieves the current readout mode from TE series cameras"""
        actual_length = (c_int)(0)
        readout_mode = (c_ubyte * 6)()

        res = ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_ReadoutModeTE.value, readout_mode, 6, byref(actual_length))
        if res != ARTEMIS_OK:
            raise CameraError(res)

        readout_mode = int.from_bytes(readout_mode[4:6], "little")
        readout_mode_enum = ReadoutModeTE(readout_mode)

        return readout_mode_enum


    @_check_connected
    def set_te_readout_mode(self, readout_mode_enum : ReadoutModeTE):
        """! Sets the readout mode of TE series cameras"""
        readout_mode = int(readout_mode_enum)
        local_readout_mode = (c_ubyte * 2)(readout_mode, readout_mode >> 8)

        res = ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_ReadoutModeTE.value, local_readout_mode, 2)
        if res != ARTEMIS_OK:
            raise CameraError(res)

    @_check_connected
    def set_te_preview_gain_offset(self, gain, offset):
        """! Sets the preview gain and offset for the connected TE series camera.
        @param gain The gain to set
        @param offset The offset/blacklevel to set """
        local_gain = (c_ubyte * 2)(gain, gain >> 8)
        res = ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_GOCustomGain.value, local_gain, 2)
        if res != ARTEMIS_OK:
            raise CameraError(res)
            
        local_offset = (c_ubyte * 2)(offset, offset >> 8)
        res = ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, local_offset, 2)
        if res != ARTEMIS_OK:
            raise CameraError(res)

    @_check_connected
    def get_te_preview_gain_offset(self):
        """! Gets the preview mode gain and offset for the connected TE series camera.
        @returns A tuple containing(in this order) the current gain, and the current"""
        actual_length = (c_int)(0)
        gain = (c_ubyte * 6)()
        offset = (c_ubyte * 6)()

        res = ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomGain.value, gain, 6, byref(actual_length))
        if res != ARTEMIS_OK:
            raise CameraError(res)

        res = ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, offset, 6, byref(actual_length))
        if res != ARTEMIS_OK:
            raise CameraError(res)

        gain = int.from_bytes(gain[4:6], "little")
        offset = int.from_bytes(offset[4:6], "little")
        return (gain, offset)

    @_check_connected
    def get_te_preview_gain_offset_range(self):
        """! Gets minimum and maximum supported values for the preview mode's gain and offset
        for the connected TE series camera.
        @returns A tuple containing (in this order) the minimum camera gain, maximum camera gain, minimum camera offset and maximum camera offset"""
        actual_length = (c_int)(0)
        gain_range = (c_ubyte * 6)()
        
        res = ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomGain.value, gain_range, 6, byref(actual_length))
        if res != ARTEMIS_OK:
            raise CameraError(res)
            
        gain_min = gain_range[0] + (gain_range[1] << 8)
        gain_max = gain_range[2] + (gain_range[3] << 8)

        offset_range = (c_ubyte * 6)()
        res = ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_GOCustomOffset.value, offset_range, 6, byref(actual_length))
        if res != ARTEMIS_OK:
            raise CameraError(res)
            
        offset_min = offset_range[0] + (offset_range[1] << 8)
        offset_max = offset_range[2] + (offset_range[3] << 8)

        return (gain_min, gain_max, offset_min, offset_max)
        
    @_check_connected
    def get_firmware_versions(self, ):
        """!Returns the fx3 and fpga firmware versions of the connected camera.
        Usage: fx3, fpga = get_firmware_versions()"""
        actual_length = (c_int)(0)
        fx3_firmware = (6 * c_ubyte)()
        fpga_firmware = (6 * c_ubyte)()

        ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_FX3Version.value, fx3_firmware, 6, byref(actual_length))
        ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_FPGAVersion.value, fpga_firmware, 6, byref(actual_length))

        fx3_maj = int.from_bytes(fx3_firmware[0:2], "little")
        fx3_min = int.from_bytes(fx3_firmware[2:4], "little")
        fx3_patch = int.from_bytes(fx3_firmware[4:6], "little")

        fpga_maj = int.from_bytes(fpga_firmware[0:2], "little")
        fpga_min = int.from_bytes(fpga_firmware[2:4], "little")
        fpga_patch = int.from_bytes(fpga_firmware[4:6], "little")

        return f"{fx3_maj}.{fx3_min}.{fx3_patch}", f"{fpga_maj}.{fpga_min}.{fpga_patch}"
    
#endregion

#region 16bit Mode

    @_check_connected
    def has_16bit_mode(self):
        """!Returns whether the camera has the 16bit mode capability. Currently only available for our ChemiMOS camera."""
        try:
            return ArtemisHasCameraSpecificOption(self._handle, CMOSOptions.ID_16BitMode.value)
        except CameraError as e:
            raise Exception("has_pad_data() unsupported for this camera type")

    @_check_connected
    def get_16bit_mode(self):
        """! Returns the current 16bit mode"""
        try:
            actual_length = (c_int)(0)
            mode_16bit = (2 * c_ubyte)()

            ArtemisCameraSpecificOptionGetData(self._handle, CMOSOptions.ID_16BitMode.value, mode_16bit, 2, byref(actual_length))

            mode_16bit = int.from_bytes(mode_16bit, "little")
            return SixteenBitMode(mode_16bit).name
        except CameraError as e:
            raise Exception("get_16bit_mode() unsupported for this camera type")

    @_check_connected
    def set_16bit_mode(self, sixteenBitMode : SixteenBitMode):
        """! Sets the current 16 bit mode for our ChemiMOS camera.
        0 = Off, 1 = Stretch, 2 = Combined Exposure, 3 = Combined Gain"""
        try:
            mode = int(sixteenBitMode)
            local_mode = (c_ubyte * 2)(mode, mode >> 8)

            ArtemisCameraSpecificOptionSetData(self._handle, CMOSOptions.ID_16BitMode.value, local_mode, 2)
        except CameraError as e:
            raise Exception("set_16bit_mode() unsupported for this camera type")

#endregion

#region FastMode
    
    @_check_connected
    def start_fast_mode(self, exposure_time_ms):
        """!Setup and start a fast mode session, images will be passed into the FastCallback function passed here.
        You will need to keep the program alive using some kind of loop or timer before calling stop_fast_exposure.
        @param exposure_time_ms The exposure length for this imaging session."""
        
        self.set_exposure_speed(ExposureSpeed.Fast)
        res = self.has_fast_mode()
        if(res):
            res = self.set_fast_callback()
            if(res):
                self.start_fast_exposure(exposure_time_ms)

#endregion


#region Column Repair

    @_check_connected
    def set_column_repair_columns(self, nColumns:int):
        """!Sets the columns on which column repair post processing is performed.
        @param nColumns The length of the array of column indicies."""

        columns = c_ushort()

        res = ArtemisSetColumnRepairColumns(self._handle, nColumns, byref(columns))
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def get_columns_repair_columns(self):
        """!Get the columns on which column repair post processing is performed."""
        nColumns = c_int()
        columns = c_ushort()

        res = ArtemisGetColumnRepairColumns(self._handle, byref(nColumns), byref(columns))
        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    @_check_connected
    def clear_column_repair_columns(self):
        """!Remove all column repair processing set previously."""

        res = ArtemisClearColumnRepairColumns(self._handle)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def set_column_Repair_fix_columns(self, enable:bool):
        """!Sets whether column repair is enabled.
        @param enable Whether column repair is enabled or not."""

        res = ArtemisSetColumnRepairFixColumns(self._handle, enable)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def get_column_repair_fix_columns(self):
        """!Retrieves whether column repair is enabled or not."""

        enabled = c_bool()
        res = ArtemisGetColumnRepairFixColumns(self._handle, byref(enabled))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return enabled.value
    
    @_check_connected
    def get_column_repair_can_fix_columns(self):
        """!Retrieves whether column repair can be enabled."""

        enabled = c_bool()
        res = ArtemisGetColumnRepairCanFixColumns(self._handle, byref(enabled))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return enabled.value
        
#endregion

#region External FilterWheel

    def check_efw_connected(func):
        """!Use this as a decorator for functions which require a valid handle to function."""

        def wrapper(self, *args, **kwargs):
            if not self.is_efw_connected():
                raise Exception("Camera is not connected. Use the connect() method to connect to the camera first.")
            
            return func(self, *args, **kwargs)

        return wrapper   

    def connect_efw(self, efw_index: int=0):
        """!Connects to an external filter wheel.
        @param camera_index The connected filter wheel index to connect to. This is 0 for the first connected one"""

        attempts = 0

        while not ArtemisEFWIsPresent(efw_index):
            time.sleep(0.1)
            attempts += 1

            if attempts > 10:
                raise Exception(f"Could not detect Filter wheel at index {efw_index}")

        self.efw_handle = ArtemisEFWConnect(efw_index)

        if not self.efw_handle:
            raise Exception(f"Could not connect to Filter wheel at index {efw_index}")  

    def is_efw_present(self, device:int):
        """!Checks if the External FW is connected at the index.
        @param device External filter wheel device index. This is 0 for the first connected EFW.
        @returns True if present, False otherwise."""

        return bool(ArtemisEFWIsPresent(device))  
    
    def is_efw_connected(self):
        """!Checks whether an External FW has been connected to.
        @returns True if connected successfully, False otherwise."""

        return bool(self.efw_handle)

    def disconnect_efw(self):
        """!Disconnects from the external filter wheel."""

        if self.is_efw_connected():
            ArtemisEFWDisconnect(self.efw_handle)      

    def efw_device_details(self):
        """!Get information on the connected external filter wheel device.
        @returns External filter wheel type and serial number."""

        type = enum_ARTEMISEFWTYPE()
        serial = create_string_buffer(100)

        res = ArtemisEFWGetDetails(self.efw_handle, byref(type), serial)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        pSerial = serial.raw.decode("utf-8")
        
        return EFWType(type.value), pSerial

    def efw_num_positons(self):
        """!Gets the number of filters inside the External filter wheel.
        @returns Number of filter positions avaialble."""

        nPos = c_int()

        res = ArtemisEFWNmrPosition(self.efw_handle, nPos)
            
        if res != ARTEMIS_OK:
            raise CameraError(res)        
        return nPos.value

    def set_efw_position(self, targetPos:int):     
        """!Move the External FW to the desired position.
        @param targetPos Desired filter position to move to."""

        nPos = c_int()
        ArtemisEFWNmrPosition(self.efw_handle, nPos)

        if targetPos < nPos.value:
            res = ArtemisEFWSetPosition(self.efw_handle, targetPos)
        else:
            raise Exception("Position not available")

        if res != ARTEMIS_OK:
            raise CameraError(res)
    
    def get_current_efw_positon(self):
        """!Gets the external filter wheel's position.
        @returns Current position."""
        curPos = c_int(0)
        isMoving = c_bool(0)

        res = ArtemisEFWGetPosition(self.efw_handle, byref(curPos), byref(isMoving))            

        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return curPos.value
    
    def check_efw_moving(self):
        """!Checks if the external filter wheel is moving.
        @returns True is moving, False otherwise."""
        curPos = c_int(0)
        isMoving = c_bool(0)

        res = ArtemisEFWGetPosition(self.efw_handle, byref(curPos), byref(isMoving))            

        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return bool(isMoving)

#endregion

#region Guiding

    @_check_connected
    def guide(self, axis:int):
        """@param axis 1 = North. 2 = South, 3 = East, 4 = West."""

        res = ArtemisGuide(self._handle, axis)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def guide_port(self, nibble:int):
        """@param nibble 0b0001 = North, 0b0010 = South, 0b0100 = East, 0b1000 = West."""

        res = ArtemisGuidePort(self._handle, nibble)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def pulse_guide(self, axis:int, ms:int):
        """@param axis 1 = North, 2 = South, 3 = East, 4 = West.
        @param ms The number of milliseconds to pulse for on the selected axis."""

        res = ArtemisPulseGuide(self._handle, axis, ms)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def stop_guiding(self):
        """!Stop Guiding"""
        
        res = ArtemisStopGuiding(self._handle)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def stop_guiding_before_download(self, enable:bool):
        """@param enable Whether to stop guiding before image has been downloaded."""

        res = ArtemisStopGuidingBeforeDownload(self._handle, enable)
        if res != ARTEMIS_OK:
            raise CameraError(res)
#endregion

#region Lens

    @_check_connected
    def get_lens_aperture(self):
        """!Gets the current lens aperture value."""
        aperture = c_int()

        res = ArtemisGetLensAperture(self._handle, aperture)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return aperture.value
    
    @_check_connected
    def get_lens_focus(self):
        """!Get the current lens focus value."""
        focus = c_int()

        res = ArtemisGetLensFocus(self._handle, focus)
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return focus.value

    @_check_connected   
    def get_lens_limits(self):
        """!Returns the lens numerical limits for the device."""
        apertureMin = c_int()
        apertureMax = c_int()
        focusMin = c_int()
        focusMax = c_int()

        res = ArtemisGetLensLimits(self._handle, byref(apertureMin), byref(apertureMax), byref(focusMin), byref(focusMax))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return apertureMin.value, apertureMax.value, focusMin.value, focusMax.value

    @_check_connected   
    def initialise_lens(self):
        """!Initialise lens controls. If not called, lens control methods will return ARTEMIS_NOT_INITIALIZED."""
        res = ArtemisInitializeLens(self._handle)
        if res != ARTEMIS_OK:
            raise CameraError(res)

    @_check_connected        
    def set_lens_aperture(self, aperture:int):
        """!Sets the lens aperture.
        @param aperture Value to set lens aperture."""

        res = ArtemisSetLensAperture(self._handle, aperture)
        if res != ARTEMIS_OK:
            raise CameraError(res)

    @_check_connected        
    def set_lens_focus(self, focus:int):
        """!Sets the lens focus
        @param focus Value to set the lens focus."""

        res = ArtemisSetLensFocus(self._handle, focus)
        if res != ARTEMIS_OK:
            raise CameraError(res) 
        
#endregion

#region Shutter

    def can_control_shutter(self):
        """!Checks whether the connected device's shutter can be opened or closed.
        @returns True if supported, False otherwise. """

        canControl = c_bool()

        res = ArtemisCanControlShutter(self._handle, byref(canControl))
        if res != ARTEMIS_OK:
            raise CameraError(res)        
        return bool(canControl.value)
    
    def open_shutter(self):
        """!Opens the shutter on device"""

        canControl = c_bool()
        ArtemisCanControlShutter(self._handle, byref(canControl))

        if canControl.value == True:
            res = ArtemisOpenShutter(self._handle)

            if res != ARTEMIS_OK:
                raise CameraError(res)
    
    def close_shutter(self):
        """!Closes the shutter on the connected device if applicable."""

        canControl = c_bool()
        ArtemisCanControlShutter(self._handle, byref(canControl))

        if canControl.value == True:
            res = ArtemisCloseShutter(self._handle)

            if res != ARTEMIS_OK:
                raise CameraError(res)
    
    def can_set_shutter_speed(self):
        """!Checks whether the connected device's shutter speed can be set.
        @returns True if supported, False otherwise. """

        canSet = c_bool()

        res = ArtemisCanSetShutterSpeed(self._handle, byref(canSet))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        return bool(canSet.value)
    
    def get_shutter_speed(self):
        """!Gets the shutter speed."""

        speed = c_int()
        res = ArtemisGetShutterSpeed(self._handle, byref(speed))
        if res != ARTEMIS_OK:
            raise CameraError(res)

        return speed.value
    
    def set_shutter_speed(self, speed:int):
        """!Sets the shutter speed, between 1 and 200
        @param speed Value settign the shutter speed."""

        canSet = c_bool()
        ArtemisCanSetShutterSpeed(self._handle, byref(canSet))

        if canSet.value == True:
            res = ArtemisSetShutterSpeed(self._handle, speed)
            if res != ARTEMIS_OK:
                raise CameraError(res)

#endregion

#region Temperature

    @_check_connected
    def set_cooling(self, target_temp:float):
        """!Sets the target temperature for the cooling of the camera. This also enables active cooling of the sensor.
        @param target_temp The target temperature in degrees centigrades."""

        res = ArtemisSetCooling(self._handle, int(target_temp * 100 + .5))
        
        if res != ARTEMIS_OK:
            raise CameraError(res) 
        
    def cooling_info(self):
        """!Retrieves information about the cooling settings for the connected camera.
        @returns Internal flags representing cooling state, Power level of the cooler, Minimum power level,
        Maximum power level and Target setpoint in degrees celsius."""

        flags = c_int()
        level = c_int()
        minlvl = c_int()
        maxlvl = c_int()
        setpoint = c_int()
        flagsList = []

        res = ArtemisCoolingInfo(self._handle, byref(flags), byref(level), byref(minlvl), byref(maxlvl), byref(setpoint))
        if res != ARTEMIS_OK:
            raise CameraError(res)

        for enum in CoolingInfo:
            if (enum & flags.value) == enum:
                flagsList.append(enum)

        return flagsList, level.value, minlvl.value, maxlvl.value, (setpoint.value/100)

    @_check_connected
    def cooler_warmup(self):
        """!Switches off the camera's integrated cooler. On some cameras, this is implemented as a slow 
        warmup to avoid thermal shock to the sensor."""

        res = ArtemisCoolerWarmUp(self._handle)

        if res != ARTEMIS_OK:
            raise CameraError(res)

    @_check_connected
    def get_temperature(self, sensor_num=1) -> float:
        """! Returns the temperature in degrees centigrade of the camera.
        @param sensor_num The sensor to read from.
        @see get_temperature_sensors_count()."""

        if sensor_num < 1:
            raise ArgumentError("Invalid range for sensor_num")

        sensor_num_int = c_int(sensor_num)
        temp = c_int()
        result = ArtemisTemperatureSensorInfo(self._handle, sensor_num_int, byref(temp))

        if result != ARTEMIS_OK:
            raise CameraError(result)

        return temp.value / 100.0
    
    @_check_connected
    def set_cooling_power(self, power:int):
        """!Sets the cooling power directly, will override set_cooling.
        @param power The power level of the cooler depending on camera, either from from 0 to 100, or 0 to 255."""

        res = ArtemisSetCoolingPower(self._handle, power)

        if res != ARTEMIS_OK:
            raise CameraError(res)
        
    @_check_connected
    def get_window_heater_power(self):
        """!Gets the window heater power."""

        heaterPower = c_int()
        res = ArtemisGetWindowHeaterPower(self._handle, byref(heaterPower))
        if res != ARTEMIS_OK:
            raise CameraError(res)
        
        return heaterPower.value
    
    @_check_connected
    def set_window_heater_power(self, heaterPower:int):
        """!Sets the window heater power
        @param heaterPower A value between 0 - 255 specifiying the power to the window heater."""

        res = ArtemisSetWindowHeaterPower(self._handle, heaterPower)
        if res != ARTEMIS_OK:
            raise CameraError(res)
#endregion
